package data.hullmods;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;

public class TMI_modPlugin extends BaseModPlugin {
    
    @Override
    public void	onApplicationLoad() {
        Global.getSettings().doesVariantExist("weirdsettings"); //Probably won't be needed next update? https://fractalsoftworks.com/forum/index.php?topic=5061.msg366712#msg366712
        Global.getSector().getPlayerFaction().addKnownHullMod("TMI_ships");
        Global.getSector().getPlayerFaction().addKnownHullMod("TMI_wings");
        Global.getSector().getPlayerFaction().addKnownHullMod("TMI_weapons");
        Global.getSector().getPlayerFaction().addKnownHullMod("TMI_beams");
        Global.getSector().getPlayerFaction().addKnownHullMod("TMI_missiles");
    }
    
    @Override
    public void onGameLoad(boolean newGame) {
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_ships")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_ships");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_wings")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_wings");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_weapons")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_weapons");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_beams")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_beams");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_missiles")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_missiles");
    }
    
    @Override
    public void afterGameSave() {
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_ships")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_ships");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_wings")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_wings");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_weapons")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_weapons");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_beams")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_beams");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_missiles")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_missiles");
    }
    

    @Override
    public void beforeGameSave() {
        Global.getSector().getPlayerFaction().removeKnownHullMod("TMI_ships");
        Global.getSector().getPlayerFaction().removeKnownHullMod("TMI_wings");
        Global.getSector().getPlayerFaction().removeKnownHullMod("TMI_weapons");
        Global.getSector().getPlayerFaction().removeKnownHullMod("TMI_beams");
        Global.getSector().getPlayerFaction().removeKnownHullMod("TMI_missiles");
    }
    
}
