package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.MutableStat;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.StatBonus;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponSize;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import org.lwjgl.input.Keyboard;

public class TMI_Beams extends BaseHullMod {
    private int presses = 0;
    private int presses2 = 0;
    
    public void addPostDescriptionSection(TooltipMakerAPI tooltip, ShipAPI.HullSize hullSize, ShipAPI ship, float width, boolean isForModSpec) {
        float opad = 10f;
        if (ship == null) {return;}
        tooltip.setBulletedListMode(null);
        if (presses >= ship.getUsableWeapons().size()) {presses = 0;}
        if (Keyboard.isKeyDown(Keyboard.getKeyIndex("F1"))) {
            if (presses2 == 0) presses2++; else {presses2--;}
        }
        List<WeaponAPI> UsableBeamWeapons = new ArrayList<WeaponAPI>();
        for (WeaponAPI weapon : ship.getUsableWeapons()) {
            if (weapon.isBeam() || weapon.isBurstBeam() && weapon.getSpec() != null && weapon.getSpec().getProjectileSpec() != null && weapon.getSpec().getProjectileSpec() instanceof BeamAPI) UsableBeamWeapons.add(weapon);
        }
        if (Keyboard.isKeyDown(Keyboard.getKeyIndex("F3"))) {
            presses++;if (presses >= UsableBeamWeapons.size()) {presses = 0;}
        }
        if (Keyboard.isKeyDown(Keyboard.getKeyIndex("F2"))) {
            presses--;if (presses < 0) {presses = !UsableBeamWeapons.isEmpty() ? UsableBeamWeapons.size()-1 : 0;}
        }
        
        tooltip.setBulletedListMode(null);
        if (!UsableBeamWeapons.isEmpty() && presses < UsableBeamWeapons.size()) {
            if (UsableBeamWeapons.get(presses) != null && !((WeaponAPI)UsableBeamWeapons.get(presses)).isDecorative() && ((WeaponAPI) UsableBeamWeapons.get(presses)).getSpec() != null) {
                WeaponAPI weapon = (WeaponAPI) UsableBeamWeapons.get(presses);
                WeaponSpecAPI weaponspec = (WeaponSpecAPI) weapon.getSpec();
                tooltip.addSectionHeading(weaponspec.getWeaponName() + " (#"+(presses+1)+")", Alignment.MID, opad);
                CargoAPI FakeCargo = Global.getFactory().createCargo(false);
                FakeCargo.addWeapons(weapon.getId(), 1);
                tooltip.showCargo(FakeCargo, 1, true, opad);
                if (presses2 == 0) {
                    tooltip.beginTable(Misc.getBasePlayerColor(), Misc.getDarkPlayerColor(), Misc.getBrightPlayerColor(), 15f, Global.getSettings().getString("timid_tmi", "stat"), 220f, Global.getSettings().getString("timid_tmi", "value"), 50f, Global.getSettings().getString("timid_tmi", "change"), 80f);
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "range"), weapon.getRange(), weaponspec.getMaxRange(), true);
                    SoTrueBestie(tooltip, weapon.isBurstBeam() ? Global.getSettings().getString("timid_tmi", "damageburst") : Global.getSettings().getString("timid_tmi", "damagesecond") , weapon.isBurstBeam() ? SoTrueBestie(weapon.getDerivedStats().getBurstDamage(), weapon.getType(), ship.getMutableStats().getBallisticWeaponDamageMult(), ship.getMutableStats().getEnergyWeaponDamageMult(), ship.getMutableStats().getMissileWeaponDamageMult()) : SoTrueBestie(weapon.getDamage().getBaseDamage(), weapon.getType(), ship.getMutableStats().getBallisticWeaponDamageMult(), ship.getMutableStats().getEnergyWeaponDamageMult(), ship.getMutableStats().getMissileWeaponDamageMult()), weapon.isBurstBeam() ? weapon.getDerivedStats().getBurstDamage() : weapon.getDamage().getBaseDamage(), true);
                    if (weapon.getFluxCostToFire() > 0) {SoTrueBestie(tooltip, weapon.isBurstBeam() ? Global.getSettings().getString("timid_tmi", "fluxburst") : Global.getSettings().getString("timid_tmi", "fluxsecond"), weapon.getFluxCostToFire()/(weaponspec.isInterruptibleBurst() ? 1 : weaponspec.getBurstSize()), SoTrueBestie(weapon.getFluxCostToFire()/(weaponspec.isInterruptibleBurst() ? 1 : weaponspec.getBurstSize()), weapon.getType(), ship.getMutableStats().getBallisticWeaponFluxCostMod(), ship.getMutableStats().getEnergyWeaponFluxCostMod(), ship.getMutableStats().getMissileWeaponFluxCostMod()), false);}
                    //if (((BeamAPI) weaponspec.getProjectileSpec()).getImpactMass > 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "impact"), ((ProjectileSpecAPI) weaponspec.getProjectileSpec()).getImpactMass(), ((ProjectileSpecAPI) weaponspec.getProjectileSpec()).getImpactMass(), true);}
                    if (weaponspec.usesAmmo() ) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "ammo"), weapon.getAmmo(), weaponspec.getMaxAmmo(),  true);}
                    if (weaponspec.getAmmoPerSecond() != 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "ammosec"), SoTrueBestie(weapon.getAmmoPerSecond(), weapon.getType(), ship.getMutableStats().getBallisticAmmoRegenMult(), ship.getMutableStats().getEnergyAmmoRegenMult(), ship.getMutableStats().getMissileAmmoRegenMult()), weaponspec.getAmmoPerSecond(),  true);}
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "hitpoints"), weapon.getMaxHealth(), SoTrueBestie(weapon.getMaxHealth(), ship.getMutableStats().getWeaponHealthBonus()), true);
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "turnrate"), "°", weapon.getTurnRate()/(weapon.getSlot().isTurret() || weapon.getSlot().isHidden() ? 5 : 1), SoTrueBestie(weapon.getTurnRate()/(weapon.getSlot().isTurret() || weapon.getSlot().isHidden() ? 5 : 1), ship.getMutableStats().getBeamWeaponTurnRateBonus()),  true);
                    if (weapon.isBurstBeam()) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "refiredelay"), weaponspec.getDerivedStats().getBurstFireDuration()+(SoTrueBestie((weaponspec.getDerivedStats().getBurstDamage()/weaponspec.getDerivedStats().getDps())-weaponspec.getDerivedStats().getBurstFireDuration(), weapon.getType(), ship.getMutableStats().getBallisticRoFMult(), ship.getMutableStats().getEnergyRoFMult(), ship.getMutableStats().getMissileRoFMult(), true)), weaponspec.getDerivedStats().getBurstFireDuration()+((weaponspec.getDerivedStats().getBurstDamage()/weaponspec.getDerivedStats().getDps())-weaponspec.getDerivedStats().getBurstFireDuration()), false);}
                    //SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "refiredelay"), Math.max(Global.getSettings().getFloat("minRefireDelay"), SoTrueBestie(weaponspec.getChargeTime()+weapon.getCooldown(), weapon.getType(), ship.getMutableStats().getBallisticRoFMult(), ship.getMutableStats().getEnergyRoFMult(), ship.getMutableStats().getMissileRoFMult(), true)) + (weaponspec.getBurstSize() > 1 ? weaponspec.getBurstSize()-1 : 1)*Math.max(weaponspec.isInterruptibleBurst() ? 0 : Global.getSettings().getFloat("minRefireDelay"), SoTrueBestie(weaponspec.getBurstSize() > 1 && !weaponspec.isInterruptibleBurst() ? (weapon.getDerivedStats().getBurstFireDuration()-weaponspec.getChargeTime())/(weaponspec.getBurstSize()-1) : 0, weapon.getType(), ship.getMutableStats().getBallisticRoFMult(), ship.getMutableStats().getEnergyRoFMult(), ship.getMutableStats().getMissileRoFMult(), true)), Math.max(Global.getSettings().getFloat("minRefireDelay"), weaponspec.getChargeTime()+weapon.getCooldown()) + (weaponspec.getBurstSize() > 1 ? weaponspec.getBurstSize()-1 : 1)*Math.max(weaponspec.isInterruptibleBurst() ? 0 : Global.getSettings().getFloat("minRefireDelay"), weaponspec.getBurstSize() > 1 && !weaponspec.isInterruptibleBurst() ? (weapon.getDerivedStats().getBurstFireDuration()-weaponspec.getChargeTime())/(weaponspec.getBurstSize()-1) : 0),  false);
                    if (weaponspec.getMaxSpread() > 0 && weaponspec.getSpreadBuildup() > 0 && weaponspec.getSpreadDecayRate() > 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "minspread"), "°", weaponspec.getMinSpread()*(weapon.getSlot().isHardpoint() ? 0.5f : 1)*ship.getMutableStats().getMaxRecoilMult().getModifiedValue(), weaponspec.getMinSpread()*(weapon.getSlot().isHardpoint() ? 0.5f : 1), false);
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "maxspread"), "°", weaponspec.getMaxSpread()*(weapon.getSlot().isHardpoint() ? 0.5f : 1)*ship.getMutableStats().getMaxRecoilMult().getModifiedValue(), weaponspec.getMaxSpread()*(weapon.getSlot().isHardpoint() ? 0.5f : 1), false);
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "spreadshot"), "°", weaponspec.getSpreadBuildup()*(weapon.getSlot().isHardpoint() ? 0.5f : 1)*ship.getMutableStats().getRecoilPerShotMult().getModifiedValue()*(weapon.getSize().equals(WeaponSize.SMALL) ? ship.getMutableStats().getRecoilPerShotMultSmallWeaponsOnly().getModifiedValue() : 1), weaponspec.getSpreadBuildup()*(weapon.getSlot().isHardpoint() ? 0.5f : 1),  false);
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "spreaddecaysec"), "°", weaponspec.getSpreadDecayRate()*(weapon.getSlot().isHardpoint() ? 0.5f : 1)*ship.getMutableStats().getRecoilDecayMult().getModifiedValue(), weaponspec.getSpreadDecayRate()*(weapon.getSlot().isHardpoint() ? 0.5f : 1), true);}
                    SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "autofireaccuracybonus"), Math.min(1, Math.max(-1, weaponspec.getAutofireAccBonus()+ship.getMutableStats().getAutofireAimAccuracy().getModifiedValue())), weaponspec.getAutofireAccBonus(), true);
                    tooltip.addTable("", 0, opad);
                }
            
                if (presses2 == 1) {
                    boolean wow = false;
                    tooltip.setBulletedListMode("• ");
                    if (!weaponspec.getAIHints().isEmpty()) {
                        for (WeaponAPI.AIHints hint : weaponspec.getAIHints()) {
                            SoTrueBestie(tooltip, hint.toString());
                        }
                        wow = true;
                    }
                    if (!weaponspec.getTags().isEmpty()) {
                        for (String tag: weaponspec.getTags()) {
                            SoTrueBestie(tooltip, tag);
                        }
                        wow = true;
                    }
                    //if (weapon.getProjectileCollisionClass() != null) {wow = true;SoTrueBestie(tooltip, weapon.getProjectileCollisionClass().toString());}
                    if (!wow) {tooltip.addPara(Global.getSettings().getString("timid_tmi", "sotruebestie"), opad);}
                    tooltip.setBulletedListMode(null);
                }
            }
        }
        tooltip.addPara(Global.getSettings().getString("timid_tmi", "F1F2F3Please"), Misc.getGrayColor(), opad);
    }
    
    private float SoTrueBestie(float float1, WeaponType weapontype, MutableStat statbonus1, MutableStat statbonus2, MutableStat statbonus3, boolean divide) {
        if (weapontype.equals(WeaponType.BALLISTIC)) return divide ? float1/statbonus1.getModifiedValue() : float1*statbonus1.getModifiedValue();
        if (weapontype.equals(WeaponType.ENERGY)) return divide ? float1/statbonus2.getModifiedValue() : float1*statbonus2.getModifiedValue();
        if (weapontype.equals(WeaponType.MISSILE)) return divide ? float1/statbonus3.getModifiedValue() : float1*statbonus3.getModifiedValue();
        return float1;
    }
    
    private float SoTrueBestie(float float1, WeaponType weapontype, MutableStat statbonus1, MutableStat statbonus2, MutableStat statbonus3) {
        return SoTrueBestie(float1, weapontype, statbonus1, statbonus2, statbonus3, false);
    }
    
    private float SoTrueBestie(float float1, WeaponType weapontype, StatBonus statbonus1, StatBonus statbonus2, StatBonus statbonus3) {
        if (weapontype.equals(WeaponType.BALLISTIC)) return ((float1/statbonus1.mult) - statbonus1.flatBonus)/(1+(statbonus1.percentMod/100));
        if (weapontype.equals(WeaponType.ENERGY)) return ((float1/statbonus2.mult) - statbonus2.flatBonus)/(1+(statbonus2.percentMod/100));
        if (weapontype.equals(WeaponType.MISSILE)) return ((float1/statbonus3.mult) - statbonus3.flatBonus)/(1+(statbonus3.percentMod/100));
        return float1;
    }
    
    private float SoTrueBestie(float float1, StatBonus statbonus) {
        return ((float1/statbonus.mult) - statbonus.flatBonus)/(1+(statbonus.percentMod/100));
    }
    
    private void SoTrueBestie(TooltipMakerAPI tooltip, String string) {
        if (!Global.getSettings().getString("timid_tmi", string).equals(String.format(Global.getSettings().getString("timid_tmi", "tmi_debug"), string))) {String text = Global.getSettings().getString("timid_tmi", string);tooltip.addPara(String.format("%s: %s", string, text), 2f, Misc.getHighlightColor(), string);}
        else {tooltip.addPara(String.format("%s", string), 2f, Misc.getHighlightColor(), string);}
    }
    
    
    private Object SoTrueBestie(TooltipMakerAPI tooltip, String string, float float1, float float2, boolean truefalse) {
        return SoTrueBestie(tooltip, string, "", float1, float2, truefalse);
    }
    
    private Object SoTrueBestie(TooltipMakerAPI tooltip, String string, String string2, float float1, float float2, boolean truefalse) {
        Color[] colors = new Color[3];
        colors[0] = Misc.getTextColor();
        colors[1] = Misc.getHighlightColor();
        colors[2] = truefalse ? float1 > float2 ?  Misc.getPositiveHighlightColor() : Misc.getNegativeHighlightColor() : float1 < float2 ?  Misc.getPositiveHighlightColor() : Misc.getNegativeHighlightColor();
        String text1 = Misc.getRoundedValue(float1)+string2;
        //String text2 = (truefalse ? float1 > float2 ? "(+"+Misc.getRoundedValue(float1-float2)+string2+")" : float1 < float2 ? "("+Misc.getRoundedValue(float1-float2)+string2+")" : "" : "");
        String text2 = (float1 != float2 ? float1 > float2 ? "(+"+Misc.getRoundedValue(float1-float2)+string2+")" : "("+Misc.getRoundedValue(float1-float2)+string2+")" : float1 < float2 ? "("+Misc.getRoundedValue(float1-float2)+string2+")" : "");
        return tooltip.addRow(Alignment.LMID, colors[0], string, Alignment.RMID, colors[1], text1, Alignment.LMID, colors[2], text2);
    }
    
	@Override
	public boolean shouldAddDescriptionToTooltip(HullSize hullSize, ShipAPI ship, boolean isForModSpec) {
		return false;
	}
    
    @Override
	public String getDescriptionParam(int index, HullSize hullSize) {
		return null;
	}

	@Override
	public boolean isApplicableToShip(ShipAPI ship) {
		return true;
	}
	
        @Override
	public String getUnapplicableReason(ShipAPI ship) {
		return null;
	}
}
