package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.sfc_specialItemsEffectRepo;
import com.fs.starfarer.api.impl.campaign.fleets.PersonalFleetHoracioCaden;
import com.fs.starfarer.api.impl.campaign.fleets.PersonalFleetOxanaHyder;
import com.fs.starfarer.api.impl.campaign.fleets.PersonalFleetScript;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BarEventManager;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.sfc_CompanyFuelBarEventCreator;
import com.fs.starfarer.api.impl.campaign.intel.events.*;
import data.scripts.listeners.sfcKweenListener;
import data.scripts.campaign.fleets.sfc_PersonalFleetHoracioCaden;
import data.scripts.campaign.fleets.sfc_PersonalFleetOxanaHyder;
import data.scripts.listeners.SFCHostileActivityListener;
import data.scripts.listeners.sfcKweenListenerFleet;
import lunalib.lunaSettings.LunaSettings;
import com.fs.starfarer.api.impl.campaign.missions.FleetCreatorMission;

import static data.scripts.campaign.sfc_customfleets.addGrandFuelFleet;
import static data.scripts.campaign.sfc_customfleets.addNFTMerchantMilitia;

public class sfc_ModPlugin extends BaseModPlugin {

    public static boolean isDE = Global.getSettings().getModManager().isModEnabled("Diktat Enhancement");
    public static boolean isLL = Global.getSettings().getModManager().isModEnabled("lunalib");
    public static boolean isCSP = Global.getSettings().getModManager().isModEnabled("Csp");
    public static boolean isUAF = Global.getSettings().getModManager().isModEnabled("uaf");
    public static boolean isArmaA = Global.getSettings().getModManager().isModEnabled("armaa");
    //public static boolean isTNP = Global.getSettings().getModManager().isModEnabled("presmattdamon_takenoprisoners");

    @Override
    public void onApplicationLoad() {
        Global.getSettings().getSkillSpec(Skills.ORDNANCE_EXPERTISE).setDescription(Global.getSettings().getString("sfc_pagsm", "sfc_ordnanceExpertiseText"));
        Global.getSettings().getSkillSpec(Skills.ORDNANCE_EXPERTISE).setAuthor(Global.getSettings().getString("sfc_pagsm", "sfc_ordnanceExpertiseAuthor"));
        Global.getSettings().getIndustrySpec("lionsguard").setDesc(Global.getSettings().getString("sfc_pagsm", "sfc_lionsguardHQ"));
        ShipVariantAPI StandardMechVariant = Global.getSettings().getVariant("sfcmurmexlg_strikecraft_Prowler");
        ShipVariantAPI StandardMechHullVariant = Global.getSettings().getVariant("sfcmurmexlg_strikecraft_Hull");
        ShipVariantAPI StandardFuelMechVariant = Global.getSettings().getVariant("sfcfuelmech_strikecraft_Escort");
        ShipVariantAPI StandardFuelMechHullVariant = Global.getSettings().getVariant("sfcfuelmech_strikecraft_Hull");
        if (Global.getSettings().getIndustrySpec("DE_Unpropaganda") != null) {
            Global.getSettings().getIndustrySpec("DE_Unpropaganda").setDesc(Global.getSettings().getString("sfc_pagsm", "sfc_deUnpropagandaText"));
            Global.getSettings().getIndustrySpec("DE_Unpropaganda").setName(Global.getSettings().getString("sfc_pagsm", "sfc_deUnpropagandaTitle"));
        }
        if (Global.getSettings().getIndustrySpec("sindrianfuel") != null) {
            Global.getSettings().getIndustrySpec("sindrianfuel").setDesc(Global.getSettings().getString("sfc_pagsm", "sfc_sindrianfuelText"));
        }
        if (isArmaA) {
            StandardMechVariant.addPermaMod("strikeCraft");
            StandardMechHullVariant.addPermaMod("strikeCraft");
            StandardFuelMechVariant.addPermaMod("strikeCraft");
            StandardFuelMechHullVariant.addPermaMod("strikeCraft");
            Global.getSettings().getHullSpec("sfcmurmexlg_strikecraft").addTag("fake_fighter");
            Global.getSettings().getHullSpec("sfcmurmexlg_strikecraft").setTravelDriveId("armaa_traveldrive");
            Global.getSettings().getHullSpec("sfcmurmexlg_strikecraft").addBuiltInMod("strikeCraft");
            Global.getSettings().getHullSpec("sfcfuelmech_strikecraft").addTag("fake_fighter");
            Global.getSettings().getHullSpec("sfcfuelmech_strikecraft").addTag("sfc_mech");
            Global.getSettings().getHullSpec("sfcfuelmech_strikecraft").setTravelDriveId("armaa_traveldrive");
            Global.getSettings().getHullSpec("sfcfuelmech_strikecraft").addBuiltInMod("strikeCraft");
        }
    }

    @Override
    public void onNewGameAfterEconomyLoad() {
        SectorAPI sector = Global.getSector();
        MarketAPI volturn = Global.getSector().getEconomy().getMarket("volturn");
        MarketAPI sindria = Global.getSector().getEconomy().getMarket("sindria");
        if (sindria != null) {
            data.scripts.campaign.sfc_people.create();
        }
        if (volturn != null) {
            addGrandFuelFleet();
            MarketAPI nachiketa = Global.getSector().getEconomy().getMarket("nachiketa");
            if (nachiketa != null) {
                addNFTMerchantMilitia();
            }
        }
        SectorEntityToken cnc = Global.getSector().getEntityById("diktat_cnc");
        if (cnc != null) {
            cnc.setCustomDescriptionId("station_sindria_sindrian_fuel");
        }
        if (!sector.hasScript(sfc_PersonalFleetOxanaHyder.class)) {
            sector.addScript(new sfc_PersonalFleetOxanaHyder());
        }
        if (!sector.hasScript(sfc_PersonalFleetHoracioCaden.class)) {
            sector.addScript(new sfc_PersonalFleetHoracioCaden());
        }
        if (!sector.hasTransientScript(SFCHostileActivityListener.class)) {
            sector.addTransientListener(new SFCHostileActivityListener());
        }
        if (!isArmaA){
            Global.getSettings().getFighterWingSpec("sfcmurmexlg_wing").addTag("no_sell");
            Global.getSettings().getFighterWingSpec("sfcmurmexlg_wing").addTag("no_drop");
            Global.getSettings().getHullSpec("sfcmurmidonlg").addTag("no_drop_salvage");
            Global.getSettings().getHullSpec("sfcmurmidonlg").addTag("no_dealer");
            Global.getSettings().getHullSpec("sfcmurmexlg_strikecraft").addTag("no_drop_salvage");
            Global.getSettings().getHullSpec("sfcmurmexlg_strikecraft").addTag("no_dealer");
        }
        if (isArmaA) {
            Global.getSector().getFaction(Factions.LIONS_GUARD).getKnownShips().add("sfcmurmidonlg");
            Global.getSector().getFaction(Factions.LIONS_GUARD).getKnownShips().add("sfcmurmexlg_strikecraft");
            Global.getSector().getFaction(Factions.LIONS_GUARD).getKnownFighters().add("sfcmurmexlg_wing");
            Global.getSettings().getHullSpec("sfcmurmidonlg").addTag("LG_bp");
            Global.getSettings().getHullSpec("sfcmurmexlg_strikecraft").addTag("LG_bp");
            Global.getSettings().getFighterWingSpec("sfcmurmexlg_wing").addTag("LG_bp");
        }
    }

    @Override
    public void onNewGameAfterTimePass() {
        MarketAPI sindria = Global.getSector().getEconomy().getMarket("sindria");
        if (sindria != null) {
            if (isDE) {
                boolean DEenablelitemode = Global.getSettings().getBoolean("DEenablelitemode");
                if (isLL) {
                    DEenablelitemode = LunaSettings.getBoolean("Diktat Enhancement", "DEenablelitemode");
                }
                if (!DEenablelitemode) {
                    MarketAPI andor = Global.getSector().getStarSystem("Andor").getEntityById("ryzan_supercomplex").getMarket();
                    PersonAPI dejalecto = Global.getSector().getImportantPeople().getPerson("dejalecto");
                    if (andor != null) {
                        dejalecto.setPostId("sfcregmanager");
                        dejalecto.getStats().setSkillLevel(Skills.INDUSTRIAL_PLANNING, 1);
                        dejalecto.getStats().setSkillLevel(Skills.TACTICAL_DRILLS, 1);
                        andor.setAdmin(dejalecto);
                        andor.getCommDirectory().addPerson(dejalecto, 0);
                        andor.addPerson(dejalecto);
                    }
                }
            }
        }
    }

    public void onGameLoad(final boolean isNewGame) {
        sfc_specialItemsEffectRepo.addItemEffectsToVanillaRepo();
        BarEventManager bar = BarEventManager.getInstance();
        SectorAPI sector = Global.getSector();
        boolean sfcKweenWatch = Global.getSector().getMemory().contains("$sfcSetupKweenMeeting");
        boolean sfcZigguratFought = Global.getSector().getMemory().contains("$sfc_FoughtZig");
        if (!sector.getListenerManager().hasListenerOfClass(sfcKweenListenerFleet.class))
            sector.getListenerManager().addListener(new sfcKweenListenerFleet());
        if (!bar.hasEventCreator(sfc_CompanyFuelBarEventCreator.class)) {
            bar.addEventCreator(new sfc_CompanyFuelBarEventCreator());
        }
        if (!sfcKweenWatch) {
            {
                sector.addTransientListener(new sfcKweenListener());
            }
        }
        if (sector.hasScript(PersonalFleetHoracioCaden.class)) {
            PersonalFleetScript fleetScript = null;

            for (EveryFrameScript script : Global.getSector().getScripts()) {
                if (script instanceof PersonalFleetHoracioCaden) {
                    fleetScript = (PersonalFleetHoracioCaden) script;
                }
            }

            if (fleetScript != null) {
                CampaignFleetAPI fleet = fleetScript.getFleet();
                if (fleet != null) {
                    fleet.getContainingLocation().removeEntity(fleet);
                }
                sector.removeScript(fleetScript);
            }
        }
        if (sector.hasScript(PersonalFleetOxanaHyder.class)) {
            PersonalFleetScript fleetScript = null;

            for (EveryFrameScript script : Global.getSector().getScripts()) {
                if (script instanceof PersonalFleetOxanaHyder) {
                    fleetScript = (PersonalFleetOxanaHyder) script;
                }
            }

            if (fleetScript != null) {
                CampaignFleetAPI fleet = fleetScript.getFleet();
                if (fleet != null) {
                    fleet.getContainingLocation().removeEntity(fleet);
                }
                sector.removeScript(fleetScript);
            }
        }
        if (!sector.getListenerManager().hasListenerOfClass(SFCHostileActivityListener.class)) {
            sector.addTransientListener(new SFCHostileActivityListener());
        }
    }
}