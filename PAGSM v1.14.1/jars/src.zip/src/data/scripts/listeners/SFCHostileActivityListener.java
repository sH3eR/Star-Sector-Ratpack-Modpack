package data.scripts.listeners;

import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.intel.events.*;

public class SFCHostileActivityListener extends BaseCampaignEventListener {

    public SFCHostileActivityListener() {
        super(false);
    }

    public void reportPlayerClosedMarket(MarketAPI market) {
        HostileActivityEventIntel HAIntel = HostileActivityEventIntel.get();
        if (HAIntel != null) {
            while (HAIntel.getActivityOfClass(SindrianDiktatHostileActivityFactor.class) != null) {
                HAIntel.removeActivityCause(SindrianDiktatHostileActivityFactor.class, SindrianDiktatStandardActivityCause.class);
            }
            if (HAIntel.getActivityOfClass(SFCHostileActivityFactor.class) == null) {
                HAIntel.addActivity(new SFCHostileActivityFactor(HAIntel), new SFCStandardActivityCause(HAIntel));
            }
        }
    }
}
