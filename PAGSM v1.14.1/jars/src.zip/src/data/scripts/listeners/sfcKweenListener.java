package data.scripts.listeners;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.util.Misc;

public class sfcKweenListener extends BaseCampaignEventListener {
    public sfcKweenListener() {
        super(false);
    }

    public void reportPlayerClosedMarket(MarketAPI market) {

        int requiredCounter = 2;
        int counter = 0;
        int turnedIn = Global.getSector().getFaction(Factions.DIKTAT).getMemoryWithoutUpdate().getInt("$turnedIn_allCores");
        int sfcHelped = Global.getSector().getPlayerPerson().getMemoryWithoutUpdate().getInt("$sfcnpchigh");
        int playerLevel = Global.getSector().getPlayerPerson().getMemoryWithoutUpdate().getInt("$level");

        if (Global.getSector().getMemoryWithoutUpdate().getBoolean("$sdtu_missionCompleted")) counter+= 2;
        if (Global.getSector().getMemoryWithoutUpdate().getBoolean("$defeatedDiktatAttack")) counter+= 2;
        if (Global.getSector().getMemoryWithoutUpdate().getBoolean("$sfcGFF_outta_gas")) counter+= 2;
        if (Global.getSector().getMemoryWithoutUpdate().getBoolean("$gaATG_missionCompleted")) counter++;
        if (Global.getSector().getMemoryWithoutUpdate().getBoolean("$lke_missionCompleted")) counter++;
        if (Global.getSector().getMemoryWithoutUpdate().getBoolean("$nex_remM1_missionCompleted")) counter++;
        if (Global.getSector().getMemoryWithoutUpdate().getBoolean("$BBPSeraphCellProtoTestPilot")) counter++;
        if (Global.getSector().getMemoryWithoutUpdate().getBoolean("$BBPOperationBS_completed")) counter++;
        if (Misc.getPlayerMarkets(true).size() > 0) counter++;
        if (turnedIn >= 3) counter++;
        if (sfcHelped >= 2) counter++;
        if (playerLevel >= 10) counter++;

        PersonAPI kim = Global.getSector().getImportantPeople().getPerson("eiskimquy");
        if (kim != null) {
            MemoryAPI memory = kim.getMemoryWithoutUpdate();
            if (memory.getBoolean("$EISDoneQuest1")) counter++;
            if (memory.getBoolean("$EISDoneQuest2")) counter++;
        }

        if (counter >= requiredCounter) {
            Global.getSector().getMemory().set("$sfcSetupKweenMeeting", true);
            Global.getSector().removeListener(this);
        }
    }
}