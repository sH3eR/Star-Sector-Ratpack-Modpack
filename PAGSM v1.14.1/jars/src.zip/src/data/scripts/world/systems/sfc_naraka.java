/*package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;

public class sfc_naraka {

    public void generate(SectorAPI sector) {

        StarSystemAPI system = sector.createStarSystem("Naraka");

        SectorEntityToken nfthqstation = system.addCustomEntity("nft_hq", "", "station_side05", "Hegemony");
        nfthqstation.setInteractionImage("illustrations", "academy");
        nfthqstation.setCircularOrbitPointingDown(system.getEntityById("nachiketa"), 45, 400, 50);
        nfthqstation.setCustomDescriptionId("nft_hq_station");*/