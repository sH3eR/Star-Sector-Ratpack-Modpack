package data.scripts.campaign;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.skills.OfficerTraining;
import com.fs.starfarer.api.util.Misc;

public class sfc_customfleets {
    public static void addGrandFuelFleet() {
    SectorAPI sector = Global.getSector();
    StarSystemAPI system = sector.getStarSystem("Askonia");
    SectorEntityToken sfcvol = system.getEntityById("volturn");


        PersonAPI person1 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person1.setId("sfc_generic_officer1");
        person1.setPostId(Ranks.POST_OFFICER);
        person1.setRankId(Ranks.POST_OFFICER);
        person1.setPersonality(Personalities.AGGRESSIVE);
        person1.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person1.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person1.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person1.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person1.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person1.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person1.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person1.addTag("coff_nocapture");
        person1.getStats().setLevel(7);

        PersonAPI person2 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person2.setId("sfc_generic_officer2");
        person2.setPostId(Ranks.POST_OFFICER);
        person2.setRankId(Ranks.POST_OFFICER);
        person2.setPersonality(Personalities.AGGRESSIVE);
        person2.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person2.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person2.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person2.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person2.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person2.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person2.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person2.addTag("coff_nocapture");
        person2.getStats().setLevel(7);

        PersonAPI person3 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person3.setId("sfc_generic_officer3");
        person3.setPostId(Ranks.POST_OFFICER);
        person3.setRankId(Ranks.POST_OFFICER);
        person3.setPersonality(Personalities.AGGRESSIVE);
        person3.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person3.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person3.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person3.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person3.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person3.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person3.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person3.addTag("coff_nocapture");
        person3.getStats().setLevel(7);

        PersonAPI person4 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person4.setId("sfc_generic_officer4");
        person4.setPostId(Ranks.POST_OFFICER);
        person4.setRankId(Ranks.POST_OFFICER);
        person4.setPersonality(Personalities.AGGRESSIVE);
        person4.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person4.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person4.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person4.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person4.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person4.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person4.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person4.addTag("coff_nocapture");
        person4.getStats().setLevel(7);

        PersonAPI person5 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person5.setId("sfc_generic_officer5");
        person5.setPostId(Ranks.POST_OFFICER);
        person5.setRankId(Ranks.POST_OFFICER);
        person5.setPersonality(Personalities.AGGRESSIVE);
        person5.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person5.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person5.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person5.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person5.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person5.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person5.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person5.addTag("coff_nocapture");
        person5.getStats().setLevel(7);

        PersonAPI person6 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person6.setId("sfc_generic_officer6");
        person6.setPostId(Ranks.POST_OFFICER);
        person6.setRankId(Ranks.POST_OFFICER);
        person6.setPersonality(Personalities.AGGRESSIVE);
        person6.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person6.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person6.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person6.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person6.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person6.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person6.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person6.addTag("coff_nocapture");
        person6.getStats().setLevel(7);

        PersonAPI reckless1 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        reckless1.setId("sfc_reckless1");
        reckless1.setPostId(Ranks.POST_OFFICER);
        reckless1.setRankId(Ranks.POST_OFFICER);
        reckless1.setPersonality(Personalities.RECKLESS);
        reckless1.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        reckless1.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        reckless1.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        reckless1.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        reckless1.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        reckless1.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        reckless1.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        reckless1.addTag("coff_nocapture");
        reckless1.getStats().setLevel(7);

        PersonAPI reckless2 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        reckless2.setId("sfc_reckless2");
        reckless2.setPostId(Ranks.POST_OFFICER);
        reckless2.setRankId(Ranks.POST_OFFICER);
        reckless2.setPersonality(Personalities.RECKLESS);
        reckless2.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        reckless2.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        reckless2.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        reckless2.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        reckless2.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        reckless2.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        reckless2.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        reckless2.addTag("coff_nocapture");
        reckless2.getStats().setLevel(7);

        PersonAPI reckless3 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        reckless3.setId("sfc_reckless3");
        reckless3.setPostId(Ranks.POST_OFFICER);
        reckless3.setRankId(Ranks.POST_OFFICER);
        reckless3.setPersonality(Personalities.RECKLESS);
        reckless3.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        reckless3.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        reckless3.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        reckless3.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        reckless3.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        reckless3.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        reckless3.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        reckless3.addTag("coff_nocapture");
        reckless3.getStats().setLevel(7);

    FleetParamsV3 sfcParams = new FleetParamsV3(
            sfcvol.getMarket(), // add a source(has to be from a MarketAPI)
            null, // loc in hyper; don't need if have market
            "sindrian_diktat",
            2f, // quality override route.getQualityOverride()
            FleetTypes.PATROL_LARGE,
            1f, // combatPts(minimal so special ships can be added)(1000f otherwise)
            0f, // freighterPts
            0f, // tankerPts
            0f, // transportPts
            0f, // linerPts
            0f, // utilityPts
            0f// qualityMod
    );
    sfcParams.officerNumberMult = 2f;
    sfcParams.officerLevelBonus = 4;
    sfcParams.officerNumberBonus = 4;
    sfcParams.officerLevelLimit = 10; // Global.getSettings().getInt("officerMaxLevel") + (int) OfficerTraining.MAX_LEVEL_BONUS;
    sfcParams.modeOverride = FactionAPI.ShipPickMode.PRIORITY_THEN_ALL;
    sfcParams.averageSMods = 1;
    sfcParams.commander = Global.getSector().getImportantPeople().getPerson("sfcyenni");
    sfcParams.flagshipVariantId = "sfciapetus_Mixed";
    CampaignFleetAPI sfcFuelFleet = FleetFactoryV3.createFleet(sfcParams);
    if (sfcFuelFleet == null || sfcFuelFleet.isEmpty()) return;
    sfcFuelFleet.setFaction("sindrian_diktat", true);
    sfcFuelFleet.getFlagship().setShipName("SFS Fuel Eternal");
    sfcFuelFleet.getFlagship().setId("sfciapetus_Mixed");
    sfcFuelFleet.getFleetData().addFleetMember("sfcskyrend_Barrage").setCaptain(person1);
    sfcFuelFleet.getFleetData().addFleetMember("sfcskyrend_Beamer");
    sfcFuelFleet.getFleetData().addFleetMember("sfcprometheus_vanguard").setCaptain(person2);
    sfcFuelFleet.getFleetData().addFleetMember("sfcprometheus_barrage");
    sfcFuelFleet.getFleetData().addFleetMember("sfcmenoetius_Defense");
    sfcFuelFleet.getFleetData().addFleetMember("sfcepimetheus_Experimental").setCaptain(person3);
    sfcFuelFleet.getFleetData().addFleetMember("sfccrius_Blaster").setCaptain(person4);
    sfcFuelFleet.getFleetData().addFleetMember("sfccrius_Blaster");
    sfcFuelFleet.getFleetData().addFleetMember("sfccrius_Pressure");
    sfcFuelFleet.getFleetData().addFleetMember("sfccrius_Pressure");
    sfcFuelFleet.getFleetData().addFleetMember("sfcphaeton_bombard").setCaptain(person5);
    sfcFuelFleet.getFleetData().addFleetMember("sfcphaeton_bombard");
    sfcFuelFleet.getFleetData().addFleetMember("sfcphaeton_ballistics").setCaptain(person6);
    sfcFuelFleet.getFleetData().addFleetMember("sfcphaeton_ballistics");
    sfcFuelFleet.getFleetData().addFleetMember("sfcarke_Supporter");
    sfcFuelFleet.getFleetData().addFleetMember("sfcarke_Supporter");
    sfcFuelFleet.getFleetData().addFleetMember("sfcarke_Suppression");
    sfcFuelFleet.getFleetData().addFleetMember("sfcarke_Suppression");
    sfcFuelFleet.getFleetData().addFleetMember("sfcclepsydra_Standard");
    sfcFuelFleet.getFleetData().addFleetMember("sfcclepsydra_Standard");
    sfcFuelFleet.getFleetData().addFleetMember("sfcdram_assault");
    sfcFuelFleet.getFleetData().addFleetMember("sfcdram_missile");
    sfcFuelFleet.getFleetData().addFleetMember("sfclelantus_Barrage");
    sfcFuelFleet.getFleetData().addFleetMember("sfclelantus_Vanguard");
    sfcFuelFleet.getFleetData().addFleetMember("sfctahlanbento_Pulser");
    sfcFuelFleet.getFleetData().addFleetMember("sfcbia_Hunter");
    sfcFuelFleet.getFleetData().addFleetMember("sfcbia_Hunter");
    sfcFuelFleet.getFleetData().addFleetMember("sfctalaria_Beamer").setCaptain(reckless1);
    sfcFuelFleet.getFleetData().addFleetMember("sfctalaria_Strike").setCaptain(reckless2);
    sfcFuelFleet.getFleetData().addFleetMember("sfctalaria_Overdriven").setCaptain(reckless3);
    sfcFuelFleet.getFleetData().addFleetMember("sfcslent_Offense");
    sfcFuelFleet.getFleetData().addFleetMember("sfcslent_Offense");
    sfcFuelFleet.getFleetData().addFleetMember("sfcslent_Offense");
    sfcFuelFleet.getFleetData().addFleetMember("sfcslent_Offense");
    sfcFuelFleet.getFleetData().addFleetMember("sfcslent_Offense");
    sfcFuelFleet.getFleetData().addFleetMember("sfcpolus_Torpedo");
    sfcFuelFleet.getFleetData().addFleetMember("sfcpolus_Torpedo");
    sfcFuelFleet.getFleetData().addFleetMember("sfcpolus_Torpedo");
    sfcFuelFleet.getFleetData().addFleetMember("sfccoeus_Patrol");
    sfcFuelFleet.getFleetData().addFleetMember("sfccoeus_Patrol");
    sfcFuelFleet.setNoFactionInName(true);
    sfcFuelFleet.setName("The Grand Fuel Fleet");
    sfcvol.getContainingLocation().addEntity(sfcFuelFleet);
    sfcFuelFleet.setAI(Global.getFactory().createFleetAI(sfcFuelFleet));
    //fleet.setMarket(sfcvol.getMarket());
    sfcFuelFleet.setLocation(sfcvol.getLocation().x, sfcvol.getLocation().y);
    sfcFuelFleet.setFacing((float) Math.random() * 360f);
    sfcFuelFleet.getAI().addAssignment(FleetAssignment.DEFEND_LOCATION, sfcvol, (float) Math.random() * 90000f, null);
    sfcFuelFleet.getMemoryWithoutUpdate().set("$chatter_introSplash_name", sfcFuelFleet.getCommander().getNameString());
    sfcFuelFleet.getFleetData().sort();

    //fleet after defeat
    FleetParamsV3 sfcParams2 = new FleetParamsV3(
            sfcvol.getMarket(), // add a source(has to be from a MarketAPI)
            null, // loc in hyper; don't need if have market
            "sindrian_diktat",
            2f, // quality override route.getQualityOverride()
            FleetTypes.PATROL_LARGE,
            300f, // combatPts(minimal so special ships can be added)(1000f otherwise)
            0f, // freighterPts
            0f, // tankerPts
            0f, // transportPts
            0f, // linerPts
            0f, // utilityPts
            0f// qualityMod
    );

    sfcParams2.officerNumberMult = 2f;
    sfcParams2.officerLevelBonus = 4;
    sfcParams2.officerNumberBonus = 4;
    sfcParams2.officerLevelLimit = 10; // Global.getSettings().getInt("officerMaxLevel") + (int) OfficerTraining.MAX_LEVEL_BONUS;
    sfcParams2.modeOverride = FactionAPI.ShipPickMode.PRIORITY_THEN_ALL;
    sfcParams2.averageSMods = 1;

    data.scripts.listeners.SFCGrandFuelFleetRespawnTracker.register(sfcFuelFleet, sfcParams, sfcParams2, "$sfcGFF_outta_gas");

}

    public static void addNFTMerchantMilitia() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Naraka");
        SectorEntityToken nachiketa = system.getEntityById("nachiketa");
        FleetParamsV3 nftParams = new FleetParamsV3(
                nachiketa.getMarket(), // add a source(has to be from a MarketAPI)
                null, // loc in hyper; don't need if have market
                "hegemony",
                1f, // quality override route.getQualityOverride()
                FleetTypes.TASK_FORCE,
                50f, // combatPts(minimal so special ships can be added)
                0f, // freighterPts
                0f, // tankerPts
                0f, // transportPts
                0f, // linerPts
                0f, // utilityPts
                0f// qualityMod
        );
        nftParams.officerNumberMult = 1f;
        nftParams.officerLevelBonus = 3;
        nftParams.officerNumberBonus = 3;
        nftParams.officerLevelLimit = Global.getSettings().getInt("officerMaxLevel") + (int) OfficerTraining.MAX_LEVEL_BONUS;
        nftParams.modeOverride = FactionAPI.ShipPickMode.ALL;
        nftParams.averageSMods = 1;
        nftParams.flagshipVariantId = "eagle_xiv_Elite";
        CampaignFleetAPI nftFleet = FleetFactoryV3.createFleet(nftParams);
        if (nftFleet == null || nftFleet.isEmpty()) return;
        nftFleet.setFaction("hegemony", true);
        nftFleet.getFlagship().setShipName("NMS Pyramid");
        nftFleet.getFlagship().setId("eagle_xiv_Elite");
        nftFleet.getFleetData().addFleetMember("condor_Support");
        nftFleet.getFleetData().addFleetMember("condor_Support");
        nftFleet.getFleetData().addFleetMember("hammerhead_Support");
        nftFleet.getFleetData().addFleetMember("hammerhead_Support");
        nftFleet.getFleetData().addFleetMember("hammerhead_Support");
        nftFleet.getFleetData().addFleetMember("enforcer_Balanced");
        nftFleet.getFleetData().addFleetMember("enforcer_Balanced");
        nftFleet.getFleetData().addFleetMember("enforcer_Balanced");
        nftFleet.getFleetData().addFleetMember("manticore_Support");
        nftFleet.getFleetData().addFleetMember("manticore_Support");
        nftFleet.getFleetData().addFleetMember("manticore_Support");
        nftFleet.getFleetData().addFleetMember("mule_Standard");
        nftFleet.getFleetData().addFleetMember("mule_Standard");
        nftFleet.getFleetData().addFleetMember("mule_Standard");
        nftFleet.getFleetData().addFleetMember("mule_Standard");
        nftFleet.getFleetData().addFleetMember("kite_hegemony_Interceptor");
        nftFleet.getFleetData().addFleetMember("kite_hegemony_Interceptor");
        nftFleet.getFleetData().addFleetMember("kite_hegemony_Interceptor");
        nftFleet.getFleetData().addFleetMember("kite_Support");
        nftFleet.getFleetData().addFleetMember("kite_Support");
        nftFleet.getFleetData().addFleetMember("kite_Support");
        nftFleet.setNoFactionInName(true);
        nftFleet.setName("NFT, Inc. Merchant Militia");
        nachiketa.getContainingLocation().addEntity(nftFleet);
        nftFleet.setAI(Global.getFactory().createFleetAI(nftFleet));
        nftFleet.setLocation(nachiketa.getLocation().x, nachiketa.getLocation().y);
        nftFleet.setFacing((float) Math.random() * 360f);
        nftFleet.getAI().addAssignment(FleetAssignment.DEFEND_LOCATION, nachiketa, (float) Math.random() * 90000f, null);

        data.scripts.listeners.SFCRespawningFleetTracker.register(nftFleet, nftParams);
        //Misc.makeUnimportant(nftFleet, MemFlags.ENTITY_MISSION_IMPORTANT);
    }
}

//private static String sfc_OEText = Global.getSettings().getString("sfc_pagsm", "sfc_ordnanceExpertiseText");
//private static String sfc_OEAuthor = Global.getSettings().getString("sfc_pagsm", "sfc_ordnanceExpertiseAuthor");
//private static String sfc_lionsguardHQ = Global.getSettings().getString("sfc_pagsm", "sfc_lionsguardHQ");
//rivate static String sfc_deUnpropagandaTitle = Global.getSettings().getString("sfc_pagsm", "sfc_deUnpropagandaTitle");
//private static String sfc_deUnpropagandaText = Global.getSettings().getString("sfc_pagsm", "sfc_deUnpropagandaText");


    /*private static void addGrandFuelFleet() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Askonia");
        SectorEntityToken sfcvol = system.getEntityById("volturn");

        ImportantPeopleAPI ip = Global.getSector().getImportantPeople();

        PersonAPI sfcyenniPerson = Global.getFactory().createPerson();
        sfcyenniPerson.setId(sfcyenni);
        sfcyenniPerson.setFaction(Factions.DIKTAT);
        sfcyenniPerson.setGender(Gender.FEMALE);
        sfcyenniPerson.setPostId("sfcfleetadmiral");
        sfcyenniPerson.setRankId(Ranks.SPACE_ADMIRAL);
        sfcyenniPerson.setPersonality(Personalities.AGGRESSIVE);
        sfcyenniPerson.setImportance(PersonImportance.HIGH);
        sfcyenniPerson.setVoice(Voices.SOLDIER);
        sfcyenniPerson.getName().setFirst("Ruka");
        sfcyenniPerson.getName().setLast("Yenni");
        sfcyenniPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcyenni"));
        sfcyenniPerson.getStats().setLevel(15);
        sfcyenniPerson.getStats().setSkillLevel("sfc_titan", 2);
        sfcyenniPerson.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        sfcyenniPerson.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        sfcyenniPerson.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        sfcyenniPerson.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        sfcyenniPerson.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 2);
        sfcyenniPerson.getStats().setSkillLevel(Skills.HELMSMANSHIP, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.COORDINATED_MANEUVERS, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.CREW_TRAINING, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.OFFICER_TRAINING, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.SUPPORT_DOCTRINE, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.TACTICAL_DRILLS, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.OFFICER_MANAGEMENT, 1);
        sfcyenniPerson.addTag("coff_forcecapture");
        sfcyenniPerson.addTag("coff_prisonerdialog");
        sfcyenniPerson.getMemoryWithoutUpdate().set("$coff_allowedactions", "talk");
        sfcyenniPerson.getMemoryWithoutUpdate().set("$coff_dialogtrigger", "sfcyenni");
        sfcyenniPerson.getMemoryWithoutUpdate().set("$nex_noOfficerDeath", true);
        sfcyenniPerson.getMemoryWithoutUpdate().set("$chatterChar", "sfcyenni");
        ip.addPerson(sfcyenniPerson);

        PersonAPI person1 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person1.setId("sfc_generic_officer1");
        person1.setPostId(Ranks.POST_OFFICER);
        person1.setRankId(Ranks.POST_OFFICER);
        person1.setPersonality(Personalities.AGGRESSIVE);
        person1.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person1.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person1.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person1.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person1.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person1.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person1.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person1.addTag("coff_nocapture");
        person1.getStats().setLevel(7);

        PersonAPI person2 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person2.setId("sfc_generic_officer2");
        person2.setPostId(Ranks.POST_OFFICER);
        person2.setRankId(Ranks.POST_OFFICER);
        person2.setPersonality(Personalities.AGGRESSIVE);
        person2.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person2.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person2.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person2.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person2.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person2.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person2.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person2.addTag("coff_nocapture");
        person2.getStats().setLevel(7);

        PersonAPI person3 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person3.setId("sfc_generic_officer3");
        person3.setPostId(Ranks.POST_OFFICER);
        person3.setRankId(Ranks.POST_OFFICER);
        person3.setPersonality(Personalities.AGGRESSIVE);
        person3.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person3.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person3.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person3.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person3.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person3.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person3.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person3.addTag("coff_nocapture");
        person3.getStats().setLevel(7);

        PersonAPI person4 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person4.setId("sfc_generic_officer4");
        person4.setPostId(Ranks.POST_OFFICER);
        person4.setRankId(Ranks.POST_OFFICER);
        person4.setPersonality(Personalities.AGGRESSIVE);
        person4.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person4.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person4.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person4.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person4.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person4.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person4.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person4.addTag("coff_nocapture");
        person4.getStats().setLevel(7);

        PersonAPI person5 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person5.setId("sfc_generic_officer5");
        person5.setPostId(Ranks.POST_OFFICER);
        person5.setRankId(Ranks.POST_OFFICER);
        person5.setPersonality(Personalities.AGGRESSIVE);
        person5.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person5.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person5.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person5.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person5.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person5.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person5.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person5.addTag("coff_nocapture");
        person5.getStats().setLevel(7);

        PersonAPI person6 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person6.setId("sfc_generic_officer6");
        person6.setPostId(Ranks.POST_OFFICER);
        person6.setRankId(Ranks.POST_OFFICER);
        person6.setPersonality(Personalities.AGGRESSIVE);
        person6.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person6.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person6.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person6.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person6.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person6.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person6.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person6.addTag("coff_nocapture");
        person6.getStats().setLevel(7);

        PersonAPI reckless1 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        reckless1.setId("sfc_reckless1");
        reckless1.setPostId(Ranks.POST_OFFICER);
        reckless1.setRankId(Ranks.POST_OFFICER);
        reckless1.setPersonality(Personalities.RECKLESS);
        reckless1.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        reckless1.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        reckless1.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        reckless1.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        reckless1.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        reckless1.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        reckless1.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        reckless1.addTag("coff_nocapture");
        reckless1.getStats().setLevel(7);

        PersonAPI reckless2 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        reckless2.setId("sfc_reckless2");
        reckless2.setPostId(Ranks.POST_OFFICER);
        reckless2.setRankId(Ranks.POST_OFFICER);
        reckless2.setPersonality(Personalities.RECKLESS);
        reckless2.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        reckless2.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        reckless2.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        reckless2.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        reckless2.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        reckless2.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        reckless2.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        reckless2.addTag("coff_nocapture");
        reckless2.getStats().setLevel(7);

        PersonAPI reckless3 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        reckless3.setId("sfc_reckless3");
        reckless3.setPostId(Ranks.POST_OFFICER);
        reckless3.setRankId(Ranks.POST_OFFICER);
        reckless3.setPersonality(Personalities.RECKLESS);
        reckless3.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        reckless3.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        reckless3.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        reckless3.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        reckless3.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        reckless3.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        reckless3.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        reckless3.addTag("coff_nocapture");
        reckless3.getStats().setLevel(7);


        FleetParamsV3 sfcParams = new FleetParamsV3(
                sfcvol.getMarket(), // add a source(has to be from a MarketAPI)
                null, // loc in hyper; don't need if have market
                "sindrian_diktat",
                2f, // quality override route.getQualityOverride()
                FleetTypes.PATROL_LARGE,
                1f, // combatPts(minimal so special ships can be added)(1000f otherwise)
                0f, // freighterPts
                0f, // tankerPts
                0f, // transportPts
                0f, // linerPts
                0f, // utilityPts
                0f// qualityMod
        );
        sfcParams.officerNumberMult = 2f;
        sfcParams.officerLevelBonus = 4;
        sfcParams.officerNumberBonus = 4;
        sfcParams.officerLevelLimit = 10; // Global.getSettings().getInt("officerMaxLevel") + (int) OfficerTraining.MAX_LEVEL_BONUS;
        sfcParams.modeOverride = FactionAPI.ShipPickMode.PRIORITY_THEN_ALL;
        sfcParams.averageSMods = 1;
        sfcParams.commander = Global.getSector().getImportantPeople().getPerson(sfcyenni);
        sfcParams.flagshipVariantId = "sfciapetus_Mixed";
        CampaignFleetAPI sfcFuelFleet = FleetFactoryV3.createFleet(sfcParams);
        if (sfcFuelFleet == null || sfcFuelFleet.isEmpty()) return;
        sfcFuelFleet.setFaction("sindrian_diktat", true);
        sfcFuelFleet.getFlagship().setShipName("SFS Fuel Eternal");
        sfcFuelFleet.getFlagship().setId("sfciapetus_Mixed");
        sfcFuelFleet.getFleetData().addFleetMember("sfcskyrend_Barrage").setCaptain(person1);
        sfcFuelFleet.getFleetData().addFleetMember("sfcskyrend_Beamer");
        sfcFuelFleet.getFleetData().addFleetMember("sfcprometheus_vanguard").setCaptain(person2);
        sfcFuelFleet.getFleetData().addFleetMember("sfcprometheus_barrage");
        sfcFuelFleet.getFleetData().addFleetMember("sfcmenoetius_Defense");
        sfcFuelFleet.getFleetData().addFleetMember("sfcepimetheus_Experimental").setCaptain(person3);
        sfcFuelFleet.getFleetData().addFleetMember("sfccrius_Blaster").setCaptain(person4);
        sfcFuelFleet.getFleetData().addFleetMember("sfccrius_Blaster");
        sfcFuelFleet.getFleetData().addFleetMember("sfccrius_Pressure");
        sfcFuelFleet.getFleetData().addFleetMember("sfccrius_Pressure");
        sfcFuelFleet.getFleetData().addFleetMember("sfcphaeton_bombard").setCaptain(person5);
        sfcFuelFleet.getFleetData().addFleetMember("sfcphaeton_bombard");
        sfcFuelFleet.getFleetData().addFleetMember("sfcphaeton_ballistics").setCaptain(person6);
        sfcFuelFleet.getFleetData().addFleetMember("sfcphaeton_ballistics");
        sfcFuelFleet.getFleetData().addFleetMember("sfcarke_Supporter");
        sfcFuelFleet.getFleetData().addFleetMember("sfcarke_Supporter");
        sfcFuelFleet.getFleetData().addFleetMember("sfcarke_Suppression");
        sfcFuelFleet.getFleetData().addFleetMember("sfcarke_Suppression");
        sfcFuelFleet.getFleetData().addFleetMember("sfcclepsydra_Standard");
        sfcFuelFleet.getFleetData().addFleetMember("sfcclepsydra_Standard");
        sfcFuelFleet.getFleetData().addFleetMember("sfcdram_assault");
        sfcFuelFleet.getFleetData().addFleetMember("sfcdram_missile");
        sfcFuelFleet.getFleetData().addFleetMember("sfclelantus_Barrage");
        sfcFuelFleet.getFleetData().addFleetMember("sfclelantus_Vanguard");
        sfcFuelFleet.getFleetData().addFleetMember("sfctahlanbento_Pulser");
        sfcFuelFleet.getFleetData().addFleetMember("sfcbia_Hunter");
        sfcFuelFleet.getFleetData().addFleetMember("sfcbia_Hunter");
        sfcFuelFleet.getFleetData().addFleetMember("sfctalaria_Beamer").setCaptain(reckless1);
        sfcFuelFleet.getFleetData().addFleetMember("sfctalaria_Strike").setCaptain(reckless2);
        sfcFuelFleet.getFleetData().addFleetMember("sfctalaria_Overdriven").setCaptain(reckless3);
        sfcFuelFleet.getFleetData().addFleetMember("sfcslent_Offense");
        sfcFuelFleet.getFleetData().addFleetMember("sfcslent_Offense");
        sfcFuelFleet.getFleetData().addFleetMember("sfcslent_Offense");
        sfcFuelFleet.getFleetData().addFleetMember("sfcslent_Offense");
        sfcFuelFleet.getFleetData().addFleetMember("sfcslent_Offense");
        sfcFuelFleet.getFleetData().addFleetMember("sfcpolus_Torpedo");
        sfcFuelFleet.getFleetData().addFleetMember("sfcpolus_Torpedo");
        sfcFuelFleet.getFleetData().addFleetMember("sfcpolus_Torpedo");
        sfcFuelFleet.getFleetData().addFleetMember("sfccoeus_Patrol");
        sfcFuelFleet.getFleetData().addFleetMember("sfccoeus_Patrol");
        sfcFuelFleet.setNoFactionInName(true);
        sfcFuelFleet.setName("The Grand Fuel Fleet");
        sfcvol.getContainingLocation().addEntity(sfcFuelFleet);
        sfcFuelFleet.setAI(Global.getFactory().createFleetAI(sfcFuelFleet));
        //fleet.setMarket(sfcvol.getMarket());
        sfcFuelFleet.setLocation(sfcvol.getLocation().x, sfcvol.getLocation().y);
        sfcFuelFleet.setFacing((float) Math.random() * 360f);
        sfcFuelFleet.getAI().addAssignment(FleetAssignment.DEFEND_LOCATION, sfcvol, (float) Math.random() * 90000f, null);
        sfcFuelFleet.getMemoryWithoutUpdate().set("$chatter_introSplash_name", sfcFuelFleet.getCommander().getNameString());

        //fleet after defeat
        FleetParamsV3 sfcParams2 = new FleetParamsV3(
                sfcvol.getMarket(), // add a source(has to be from a MarketAPI)
                null, // loc in hyper; don't need if have market
                "sindrian_diktat",
                2f, // quality override route.getQualityOverride()
                FleetTypes.PATROL_LARGE,
                300f, // combatPts(minimal so special ships can be added)(1000f otherwise)
                0f, // freighterPts
                0f, // tankerPts
                0f, // transportPts
                0f, // linerPts
                0f, // utilityPts
                0f// qualityMod
        );

        sfcParams2.officerNumberMult = 2f;
        sfcParams2.officerLevelBonus = 4;
        sfcParams2.officerNumberBonus = 4;
        sfcParams2.officerLevelLimit = 10; // Global.getSettings().getInt("officerMaxLevel") + (int) OfficerTraining.MAX_LEVEL_BONUS;
        sfcParams2.modeOverride = FactionAPI.ShipPickMode.PRIORITY_THEN_ALL;
        sfcParams2.averageSMods = 1;

        data.scripts.listeners.SFCGrandFuelFleetRespawnTracker.register(sfcFuelFleet, sfcParams, sfcParams2, "$sfcGFF_outta_gas");

    }

    private void addNFTMerchantMilitia() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Naraka");
        SectorEntityToken nachiketa = system.getEntityById("nachiketa");
        FleetParamsV3 nftParams = new FleetParamsV3(
                nachiketa.getMarket(), // add a source(has to be from a MarketAPI)
                null, // loc in hyper; don't need if have market
                "hegemony",
                1f, // quality override route.getQualityOverride()
                FleetTypes.TASK_FORCE,
                50f, // combatPts(minimal so special ships can be added)
                0f, // freighterPts
                0f, // tankerPts
                0f, // transportPts
                0f, // linerPts
                0f, // utilityPts
                0f// qualityMod
        );
        nftParams.officerNumberMult = 1f;
        nftParams.officerLevelBonus = 3;
        nftParams.officerNumberBonus = 3;
        nftParams.officerLevelLimit = Global.getSettings().getInt("officerMaxLevel") + (int) OfficerTraining.MAX_LEVEL_BONUS;
        nftParams.modeOverride = FactionAPI.ShipPickMode.ALL;
        nftParams.averageSMods = 1;
        nftParams.flagshipVariantId = "eagle_xiv_Elite";
        CampaignFleetAPI nftFleet = FleetFactoryV3.createFleet(nftParams);
        if (nftFleet == null || nftFleet.isEmpty()) return;
        nftFleet.setFaction("hegemony", true);
        nftFleet.getFlagship().setShipName("NMS Pyramid");
        nftFleet.getFlagship().setId("eagle_xiv_Elite");
        nftFleet.getFleetData().addFleetMember("condor_Support");
        nftFleet.getFleetData().addFleetMember("condor_Support");
        nftFleet.getFleetData().addFleetMember("hammerhead_Support");
        nftFleet.getFleetData().addFleetMember("hammerhead_Support");
        nftFleet.getFleetData().addFleetMember("hammerhead_Support");
        nftFleet.getFleetData().addFleetMember("enforcer_Balanced");
        nftFleet.getFleetData().addFleetMember("enforcer_Balanced");
        nftFleet.getFleetData().addFleetMember("enforcer_Balanced");
        nftFleet.getFleetData().addFleetMember("manticore_Support");
        nftFleet.getFleetData().addFleetMember("manticore_Support");
        nftFleet.getFleetData().addFleetMember("manticore_Support");
        nftFleet.getFleetData().addFleetMember("mule_Standard");
        nftFleet.getFleetData().addFleetMember("mule_Standard");
        nftFleet.getFleetData().addFleetMember("mule_Standard");
        nftFleet.getFleetData().addFleetMember("mule_Standard");
        nftFleet.getFleetData().addFleetMember("kite_hegemony_Interceptor");
        nftFleet.getFleetData().addFleetMember("kite_hegemony_Interceptor");
        nftFleet.getFleetData().addFleetMember("kite_hegemony_Interceptor");
        nftFleet.getFleetData().addFleetMember("kite_Support");
        nftFleet.getFleetData().addFleetMember("kite_Support");
        nftFleet.getFleetData().addFleetMember("kite_Support");
        nftFleet.setNoFactionInName(true);
        nftFleet.setName("NFT, Inc. Merchant Militia");
        nachiketa.getContainingLocation().addEntity(nftFleet);
        nftFleet.setAI(Global.getFactory().createFleetAI(nftFleet));
        nftFleet.setLocation(nachiketa.getLocation().x, nachiketa.getLocation().y);
        nftFleet.setFacing((float) Math.random() * 360f);
        nftFleet.getAI().addAssignment(FleetAssignment.DEFEND_LOCATION, nachiketa, (float) Math.random() * 90000f, null);

        data.scripts.listeners.SFCRespawningFleetTracker.register(nftFleet, nftParams);
    }*/