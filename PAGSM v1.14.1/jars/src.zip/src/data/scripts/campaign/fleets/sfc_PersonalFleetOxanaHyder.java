package data.scripts.campaign.fleets;

import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.fleets.PersonalFleetScript;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.FleetTypes;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.People;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.missions.FleetCreatorMission;
import com.fs.starfarer.api.impl.campaign.missions.hub.HubMissionWithTriggers.FleetQuality;
import com.fs.starfarer.api.impl.campaign.missions.hub.HubMissionWithTriggers.FleetSize;
import com.fs.starfarer.api.impl.campaign.missions.hub.HubMissionWithTriggers.OfficerNum;
import com.fs.starfarer.api.impl.campaign.missions.hub.HubMissionWithTriggers.OfficerQuality;
import com.fs.starfarer.api.impl.campaign.missions.hub.MissionFleetAutoDespawn;
import com.fs.starfarer.api.loading.VariantSource;

public class sfc_PersonalFleetOxanaHyder extends PersonalFleetScript {

    public sfc_PersonalFleetOxanaHyder() {
        super(People.HYDER);
        setMinRespawnDelayDays(10f);
        setMaxRespawnDelayDays(20f);
    }

    @Override
    public CampaignFleetAPI spawnFleet() {

        MarketAPI sindria = Global.getSector().getEconomy().getMarket("sindria");
        boolean fleetsupplied = Global.getSector().getMemoryWithoutUpdate().getBoolean("$sfc_aidedHyder");

        FleetCreatorMission m = new FleetCreatorMission(random);
        m.beginFleet();

        Vector2f loc = sindria.getLocationInHyperspace();

        if (fleetsupplied) {
            m.triggerCreateFleet(FleetSize.MAXIMUM, FleetQuality.SMOD_1, Factions.DIKTAT, FleetTypes.PATROL_LARGE, loc);}
        if (!fleetsupplied) {
            m.triggerCreateFleet(FleetSize.HUGE, FleetQuality.LOWER, Factions.DIKTAT, FleetTypes.TASK_FORCE, loc);}
        m.triggerSetFleetOfficers( OfficerNum.MORE, OfficerQuality.DEFAULT);
        m.triggerSetFleetCommander(getPerson());
        m.triggerSetFleetFaction(Factions.DIKTAT);
        m.triggerSetPatrol();
        m.triggerSetFleetMemoryValue(MemFlags.MEMORY_KEY_SOURCE_MARKET, sindria);
        m.triggerFleetSetNoFactionInName();
        m.triggerPatrolAllowTransponderOff();
        m.triggerFleetSetName("Askonia System Defense Armada");
        m.triggerOrderFleetPatrol(sindria.getStarSystem());

        CampaignFleetAPI fleet = m.createFleet();
        FleetMemberAPI oldFlagship = fleet.getFlagship();
        FleetMemberAPI conquest = Global.getFactory().createFleetMember(FleetMemberType.SHIP, "conquest_Elite");
        if (conquest != null && oldFlagship != null){
        fleet.getFleetData().addFleetMember(conquest);
        conquest.setCaptain(oldFlagship.getCaptain());
        oldFlagship.setFlagship(false);
        conquest.setFlagship(true);
        fleet.getFleetData().setFlagship(conquest);
        fleet.getFleetData().removeFleetMember(oldFlagship);}
        fleet.removeScriptsOfClass(MissionFleetAutoDespawn.class);
        sindria.getContainingLocation().addEntity(fleet);
        fleet.setLocation(sindria.getPlanetEntity().getLocation().x, sindria.getPlanetEntity().getLocation().y);
        fleet.setFacing((float) random.nextFloat() * 360f);
        fleet.getFlagship().setShipName("SFS Manager");
        fleet.getFleetData().sort();
        return fleet;
    }

    @Override
    public boolean canSpawnFleetNow() {
        MarketAPI sindria = Global.getSector().getEconomy().getMarket("sindria");
        if (sindria == null || sindria.hasCondition(Conditions.DECIVILIZED)) return false;
        if (!sindria.getFactionId().equals(Factions.DIKTAT)) return false;
        return true;
    }

    @Override
    public boolean shouldScriptBeRemoved() {
        return false;
    }
}