package data.scripts.campaign.fleets;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.fleets.PersonalFleetScript;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.missions.FleetCreatorMission;
import com.fs.starfarer.api.impl.campaign.missions.hub.HubMissionWithTriggers.FleetQuality;
import com.fs.starfarer.api.impl.campaign.missions.hub.HubMissionWithTriggers.FleetSize;
import com.fs.starfarer.api.impl.campaign.missions.hub.HubMissionWithTriggers.OfficerNum;
import com.fs.starfarer.api.impl.campaign.missions.hub.HubMissionWithTriggers.OfficerQuality;
import com.fs.starfarer.api.impl.campaign.missions.hub.MissionFleetAutoDespawn;
import com.fs.starfarer.api.loading.VariantSource;
import org.lwjgl.util.vector.Vector2f;

public class sfc_PersonalFleetHoracioCaden extends PersonalFleetScript {


    public sfc_PersonalFleetHoracioCaden() {
        super(People.CADEN);
        setMinRespawnDelayDays(10f);
        setMaxRespawnDelayDays(20f);
    }

    @Override
    public CampaignFleetAPI spawnFleet() {

        MarketAPI sindria = Global.getSector().getEconomy().getMarket("sindria");


        FleetCreatorMission m = new FleetCreatorMission(random);
        m.beginFleet();

        Vector2f loc = sindria.getLocationInHyperspace();

        m.triggerCreateFleet(FleetSize.MAXIMUM, FleetQuality.SMOD_2, Factions.LIONS_GUARD, FleetTypes.TASK_FORCE, loc);
        m.triggerSetFleetOfficers( OfficerNum.MORE, OfficerQuality.UNUSUALLY_HIGH);
        m.triggerSetFleetCommander(getPerson());
        m.triggerSetFleetFaction(Factions.DIKTAT);
        m.triggerSetPatrol();
        m.triggerSetFleetMemoryValue(MemFlags.MEMORY_KEY_SOURCE_MARKET, sindria);
        m.triggerFleetSetNoFactionInName();
        m.triggerFleetSetName("Lion's Guard Grand Armada");
        m.triggerPatrolAllowTransponderOff();
        m.triggerFleetSetPatrolActionText("parading");
        m.triggerOrderFleetPatrol(sindria.getStarSystem());

        CampaignFleetAPI fleet = m.createFleet();
        FleetMemberAPI oldFlagship = fleet.getFlagship();
        FleetMemberAPI executor = Global.getFactory().createFleetMember(FleetMemberType.SHIP, "executor_Elite");
        fleet.getFleetData().addFleetMember(executor);
        if (executor != null && oldFlagship != null) {
        executor.setCaptain(oldFlagship.getCaptain());
        oldFlagship.setFlagship(false);
        executor.setFlagship(true);
        fleet.getFleetData().setFlagship(executor);
        fleet.getFleetData().removeFleetMember(oldFlagship);}
        fleet.removeScriptsOfClass(MissionFleetAutoDespawn.class);
        sindria.getContainingLocation().addEntity(fleet);
        fleet.setLocation(sindria.getPlanetEntity().getLocation().x, sindria.getPlanetEntity().getLocation().y);
        fleet.setFacing((float) random.nextFloat() * 360f);
        fleet.getFlagship().setShipName("LGS The Will of Andrada");
        fleet.getFleetData().sort();
        return fleet;
    }

    @Override
    public boolean canSpawnFleetNow() {
        MarketAPI sindria = Global.getSector().getEconomy().getMarket("sindria");
        if (sindria == null || sindria.hasCondition(Conditions.DECIVILIZED)) return false;
        if (!sindria.hasIndustry(Industries.LIONS_GUARD)) return false;
        if (!sindria.getFactionId().equals(Factions.DIKTAT)) return false;
        return true;
    }

    @Override
    public boolean shouldScriptBeRemoved() {
        return false;
    }

}