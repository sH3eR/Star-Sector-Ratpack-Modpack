package data.scripts.campaign.missions;

import java.awt.Color;

import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.missions.hub.HubMissionWithSearch;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class sfc_daemonCoreMission extends HubMissionWithSearch {

    public static enum Stage {
        BRING_CORE,
        COMPLETED,
    }

    protected PersonAPI sfckween;

    @Override
    protected boolean create(MarketAPI createdAt, boolean barEvent) {
        // if already accepted by the player, abort
        if (!setGlobalReference("$sfcDaemonCore_ref")) {
            return false;
        }

        sfckween = getImportantPerson("sfckween");
        if (sfckween == null) return false;

        setStartingStage(Stage.BRING_CORE);
        addSuccessStages(Stage.COMPLETED);

        setStoryMission();

        makeImportant(sfckween, "$sfcKweenDaemonCore1_started", Stage.BRING_CORE);
        setStageOnGlobalFlag(Stage.COMPLETED, "$sfcDaemonCore_completed");
        beginStageTrigger(Stage.COMPLETED);
        triggerSetGlobalMemoryValue("$sfcDaemonCore_completed", true);

        endTrigger();

        setRepFactionChangesNone();
        setRepPersonChangesNone();
        return true;
    }

    protected void updateInteractionDataImpl() {

    }

    @Override
    public void addDescriptionForNonEndStage(TooltipMakerAPI info, float width, float height) {
        float opad = 10f;
        Color h = Misc.getHighlightColor();
        if (currentStage == Stage.BRING_CORE) {
            info.addPara("Bring a Daemon core to Head Researcher " + sfckween.getNameString() + ".", opad);
        }
    }

    @Override
    public boolean addNextStepText(TooltipMakerAPI info, Color tc, float pad) {
        Color h = Misc.getHighlightColor();
        if (currentStage == Stage.BRING_CORE) {
            info.addPara("Bring a Daemon core to Sindria", tc, pad);
            return true;
        }
        return false;
    }

    @Override
    public String getBaseName() {
        return "Acquire a Daemon core";
    }

    @Override
    public String getPostfixForState() {
        if (startingStage != null) {
            return "";
        }
        return super.getPostfixForState();
    }
}