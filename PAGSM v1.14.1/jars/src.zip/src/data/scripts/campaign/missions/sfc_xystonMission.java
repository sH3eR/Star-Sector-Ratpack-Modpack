package data.scripts.campaign.missions;

import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.missions.hub.HubMissionWithSearch;

public class sfc_xystonMission extends HubMissionWithSearch {

    public static enum Stage {
        GET_INFO,
        TRACE_ONE,
        TRACE_TWO,
        FIND_XYSTON,
        RETURN_TO_MANNFRED,
    }

    protected PersonAPI sfcmann;

    protected MarketAPI sindria;

    protected int xpReward;
    protected int payment;

    @Override
    protected boolean create(MarketAPI createdAt, boolean barEvent) {
        return false;
    }
}
