package data.scripts.campaign;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.ids.*;

public class sfc_people {
    public static boolean isDE = Global.getSettings().getModManager().isModEnabled("Diktat Enhancement");
    public static boolean isTNP = Global.getSettings().getModManager().isModEnabled("presmattdamon_takenoprisoners");
    public static boolean isCSP = Global.getSettings().getModManager().isModEnabled("Csp");
    public static boolean isUAF = Global.getSettings().getModManager().isModEnabled("uaf");

    public static String sfckween = "sfckween"; //glorious science
    public static String sfcruni = "sfcruni"; //looks familiar
    public static String sfcruni2 = "sfcruni2"; //you have met a terrible fate haven't you
    public static String sfcyenni = "sfcyenni"; //also looks familiar
    public static String sfcmann = "sfcmann"; //2nd coolest old guy in the Sindrian Fuel Company
    public static String sfcruy = "sfcruy"; //envious of the lion's guard
    public static String sfcdunn = "sfcdunn"; //loves "surprise internship" camps
    public static String sfcfleures = "sfcfleures"; //brightest flower
    public static String sfcjenkins = "sfcjenkins"; //velmarie's sass
    public static String sfcvolturny = "sfcvolturny"; //best mascot
    public static String sfcfakeandrada = "sfcfakeandrada"; //the phillip andrada experience
    public static String sfchero = "sfchero"; //a true hero of the Sindrian Fuel Company
    public static String sfcrhea = "sfcrhea"; //a true hero's assistant of the Sindrian Fuel Company
    public static String sfcfonz = "sfcfonz"; //not the fonz
    public static String sfcarthur = "sfcarthur"; //religious zealot
    public static String sfcarc = "sfcarc"; //zapata
    public static String dejalecto = "dejalecto"; //preacher for the Lion and DE integration
    public static String cspmongaera = "cspmongaera"; //deathless
    public static String nftpononzi = "nftpononzi"; //does he have an ape?
    public static String nftgimlet = "nftgimlet"; //ol' gimlet eye
    public static String feznorman = "feznorman"; //not from another mod

    public static void create() {
        createPAGSMCharacters();
    }

    public static PersonAPI createPAGSMCharacters() {
        ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Askonia");
        MarketAPI market = null;

        // unrelenting genius
        market = Global.getSector().getEconomy().getMarket("sindria");
        if (market != null) {
            PersonAPI sfckweenPerson = Global.getFactory().createPerson();
            sfckweenPerson.setId(sfckween);
            sfckweenPerson.setFaction(Factions.DIKTAT);
            sfckweenPerson.setGender(FullName.Gender.FEMALE);
            sfckweenPerson.setRankId(Ranks.SPACE_ADMIRAL);
            sfckweenPerson.setPostId("sfcheadresearcher");
            sfckweenPerson.setImportance(PersonImportance.VERY_HIGH);
            sfckweenPerson.setVoice(Voices.SCIENTIST);
            sfckweenPerson.getName().setFirst("Yunris");
            sfckweenPerson.getName().setLast("Kween");
            sfckweenPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfckween"));
            sfckweenPerson.addTag(Tags.CONTACT_UNDERWORLD);
            market.getCommDirectory().addPerson(sfckweenPerson, 2);
            market.addPerson(sfckweenPerson);
            market.getCommDirectory().getEntryForPerson(sfckweenPerson).setHidden(true);
            ip.addPerson(sfckweenPerson);

            // lobster t-shirt
            PersonAPI sfcmannPerson = Global.getFactory().createPerson();
            sfcmannPerson.setId(sfcmann);
            sfcmannPerson.setFaction(Factions.DIKTAT);
            sfcmannPerson.setGender(FullName.Gender.MALE);
            sfcmannPerson.setRankId(Ranks.SPACE_ADMIRAL);
            sfcmannPerson.setPostId("sfcleaddeveloper");
            sfcmannPerson.setImportance(PersonImportance.HIGH);
            sfcmannPerson.setVoice(Voices.SCIENTIST);
            sfcmannPerson.getName().setFirst("Gregory");
            sfcmannPerson.getName().setLast("Mannfred");
            sfcmannPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcmann"));
            sfcmannPerson.addTag(Tags.CONTACT_TRADE);
            market.getCommDirectory().addPerson(sfcmannPerson, 3);
            market.addPerson(sfcmannPerson);
            market.getCommDirectory().getEntryForPerson(sfcmannPerson).setHidden(true);
            ip.addPerson(sfcmannPerson);

            // a regular Yunifer
            PersonAPI sfcruniPerson = Global.getFactory().createPerson();
            sfcruniPerson.setId(sfcruni);
            sfcruniPerson.setFaction(Factions.DIKTAT);
            sfcruniPerson.setGender(FullName.Gender.FEMALE);
            sfcruniPerson.setRankId(Ranks.SPACE_CAPTAIN);
            sfcruniPerson.setPostId(Ranks.POST_OFFICER);
            sfcruniPerson.setPersonality(Personalities.TIMID);
            sfcruniPerson.setImportance(PersonImportance.VERY_LOW);
            sfcruniPerson.setVoice(Voices.SOLDIER);
            sfcruniPerson.getName().setFirst("Yunifer");
            sfcruniPerson.getName().setLast("Runi");
            sfcruniPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcruni"));
            sfcruniPerson.getStats().setSkillLevel("sfc_iapetus", 2);
            sfcruniPerson.getStats().setSkillLevel(Skills.POINT_DEFENSE, 2);
            sfcruniPerson.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
            sfcruniPerson.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
            sfcruniPerson.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
            sfcruniPerson.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 2);
            sfcruniPerson.getStats().setSkillLevel(Skills.SYSTEMS_EXPERTISE, 1);
            sfcruniPerson.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 1);
            sfcruniPerson.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 1);
            sfcruniPerson.getStats().setSkillLevel(Skills.ORDNANCE_EXPERTISE, 1);
            sfcruniPerson.getStats().setLevel(10);
            if (isTNP) {
                sfcruniPerson.addTag("coff_nocapture");
            }
            sfcruniPerson.getMemoryWithoutUpdate().set("$chatterChar", "sfcruni");
            sfcruniPerson.getMemoryWithoutUpdate().set("$nex_noOfficerDeath", true);
            sfcruniPerson.addTag("rat_dont_allow_for_skills");

            market.getCommDirectory().addPerson(sfcruniPerson);
            market.addPerson(sfcruniPerson);
            market.getCommDirectory().getEntryForPerson(sfcruniPerson).setHidden(true);
            ip.addPerson(sfcruniPerson);

            //a mistake was made
            PersonAPI sfcruni2Person = Global.getFactory().createPerson();
            sfcruni2Person.setId(sfcruni2);
            sfcruni2Person.setFaction(Factions.DIKTAT);
            sfcruni2Person.setGender(FullName.Gender.FEMALE);
            sfcruni2Person.setRankId(Ranks.SPACE_CAPTAIN);
            sfcruni2Person.setPostId(Ranks.POST_OFFICER);
            sfcruni2Person.setPersonality(Personalities.STEADY);
            sfcruni2Person.setImportance(PersonImportance.VERY_LOW);
            sfcruni2Person.setVoice(Voices.SOLDIER);
            sfcruni2Person.getName().setFirst("Yunifer");
            sfcruni2Person.getName().setLast("Runi");
            sfcruni2Person.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcruni2"));
            sfcruni2Person.getStats().setLevel(1);
            sfcruni2Person.getStats().setSkillLevel(Skills.GUNNERY_IMPLANTS, 1);
            sfcruni2Person.getMemoryWithoutUpdate().set("$chatterChar", "sfcthisofficer");
            sfcruni2Person.getMemoryWithoutUpdate().set("$nex_noOfficerDeath", true);

            market.getCommDirectory().addPerson(sfcruni2Person);
            market.addPerson(sfcruni2Person);
            market.getCommDirectory().getEntryForPerson(sfcruni2Person).setHidden(true);
            ip.addPerson(sfcruni2Person);

            // magic eight ball
            PersonAPI sfcfakeandradaPerson = Global.getFactory().createPerson();
            sfcfakeandradaPerson.setId(sfcfakeandrada);
            sfcfakeandradaPerson.setFaction(Factions.NEUTRAL);
            sfcfakeandradaPerson.setGender(FullName.Gender.MALE);
            sfcfakeandradaPerson.setRankId("Hologram");
            sfcfakeandradaPerson.setPostId("Hologram");
            sfcfakeandradaPerson.getName().setFirst("Phillip");
            sfcfakeandradaPerson.getName().setLast("Andrada");
            sfcfakeandradaPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcfakeandrada"));
            ip.addPerson(sfcfakeandradaPerson);

            // what kind of name is fuel frontal?
            PersonAPI sfcheroPerson = Global.getFactory().createPerson();
            sfcheroPerson.setId(sfchero);
            sfcheroPerson.setFaction(Factions.DIKTAT);
            sfcheroPerson.setGender(FullName.Gender.MALE);
            sfcheroPerson.setRankId(Ranks.SPACE_CAPTAIN);
            sfcheroPerson.setPostId(Ranks.POST_OFFICER);
            sfcheroPerson.setImportance(PersonImportance.VERY_HIGH);
            sfcheroPerson.setVoice(Voices.SOLDIER);
            sfcheroPerson.getName().setFirst("Fuel");
            sfcheroPerson.getName().setLast("Frontal");
            sfcheroPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfchero"));
            ip.addPerson(sfcheroPerson);

            // short
            PersonAPI sfcrheaPerson = Global.getFactory().createPerson();
            sfcrheaPerson.setId(sfcrhea);
            sfcrheaPerson.setFaction(Factions.DIKTAT);
            sfcrheaPerson.setGender(FullName.Gender.FEMALE);
            sfcrheaPerson.setRankId(Ranks.SPACE_LIEUTENANT);
            sfcrheaPerson.setPostId(Ranks.POST_AGENT);
            sfcrheaPerson.setImportance(PersonImportance.MEDIUM);
            sfcrheaPerson.setVoice(Voices.SOLDIER);
            sfcrheaPerson.getName().setFirst("Sindy");
            sfcrheaPerson.getName().setLast("Rhea");
            sfcrheaPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcrhea"));
            ip.addPerson(sfcrheaPerson);

            // enhanced
            PersonAPI dejalectoPerson = Global.getFactory().createPerson();
            dejalectoPerson.setId(dejalecto);
            dejalectoPerson.setFaction(Factions.LIONS_GUARD);
            dejalectoPerson.setGender(FullName.Gender.MALE);
            dejalectoPerson.setRankId("sfcexecutive");
            dejalectoPerson.setPostId("sfcexecutive");
            dejalectoPerson.setImportance(PersonImportance.VERY_HIGH);
            dejalectoPerson.getName().setFirst("Randall");
            dejalectoPerson.getName().setLast("Jalecto");
            dejalectoPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "dejalecto"));
            market.getCommDirectory().addPerson(dejalectoPerson, 1);
            market.addPerson(dejalectoPerson);
            market.getCommDirectory().getEntryForPerson(dejalectoPerson).setHidden(true);
            ip.addPerson(dejalectoPerson);
        }


        market = Global.getSector().getEconomy().getMarket("cruor");
        if (market != null) {

            market.addSubmarket("sfc_bsamarket");

            SectorEntityToken cruor = system.getEntityById("cruor");
            cruor.getMarket().addIndustry(Industries.PATROLHQ);
            cruor.getMarket().addIndustry("sfclionsoutpost");

            // gets it dunn
            PersonAPI sfcdunnPerson = Global.getFactory().createPerson();
            sfcdunnPerson.setId(sfcdunn);
            sfcdunnPerson.setFaction(Factions.DIKTAT);
            sfcdunnPerson.setGender(FullName.Gender.MALE);
            sfcdunnPerson.setRankId(Ranks.SPACE_ADMIRAL);
            sfcdunnPerson.setPostId("sfclaborchief");
            sfcdunnPerson.setImportance(PersonImportance.HIGH);
            sfcdunnPerson.getName().setFirst("Meridin");
            sfcdunnPerson.getName().setLast("Dunn");
            sfcdunnPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcdunn"));
            sfcdunnPerson.addTag(Tags.CONTACT_TRADE);
            sfcdunnPerson.setVoice(Voices.SPACER);
            sfcdunnPerson.getStats().setSkillLevel("sfc_hardwork", 1);
            sfcdunnPerson.getStats().setSkillLevel("sfc_gilded", 1);
            market.setAdmin(sfcdunnPerson);
            market.getCommDirectory().addPerson(sfcdunnPerson, 0);
            market.addPerson(sfcdunnPerson);
            ip.addPerson(sfcdunnPerson);

            // hates the Lion's Guard, and his job
            PersonAPI sfcruyPerson = Global.getFactory().createPerson();
            sfcruyPerson.setId(sfcruy);
            sfcruyPerson.setFaction(Factions.DIKTAT);
            sfcruyPerson.setGender(FullName.Gender.MALE);
            sfcruyPerson.setRankId(Ranks.SPACE_ADMIRAL);
            sfcruyPerson.setPostId("sfcsecchief");
            sfcruyPerson.setImportance(PersonImportance.MEDIUM);
            sfcruyPerson.getName().setFirst("Rudric");
            sfcruyPerson.getName().setLast("Ruy");
            sfcruyPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcruy"));
            sfcruyPerson.addTag(Tags.CONTACT_MILITARY);
            sfcruyPerson.setVoice(Voices.SOLDIER);
            market.getCommDirectory().addPerson(sfcruyPerson, 1);
            market.addPerson(sfcruyPerson);
            ip.addPerson(sfcruyPerson);

            // CSP reference
            PersonAPI cspmongaeraPerson = Global.getFactory().createPerson();
            cspmongaeraPerson.setId(cspmongaera);
            cspmongaeraPerson.setFaction(Factions.LIONS_GUARD);
            cspmongaeraPerson.setGender(FullName.Gender.FEMALE);
            cspmongaeraPerson.setRankId("sfcregmanager");
            cspmongaeraPerson.setPostId("sfcregmanager");
            cspmongaeraPerson.setImportance(PersonImportance.VERY_HIGH);
            cspmongaeraPerson.getName().setFirst("Cayista");
            cspmongaeraPerson.getName().setLast("Mongaera");
            cspmongaeraPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "cspmongaera"));
            cspmongaeraPerson.addTag(Tags.CONTACT_MILITARY);
            cspmongaeraPerson.setVoice(Voices.SOLDIER);
            market.getCommDirectory().addPerson(cspmongaeraPerson, 0);
            market.addPerson(cspmongaeraPerson);
            market.getCommDirectory().getEntryForPerson(cspmongaeraPerson).setHidden(true);
            ip.addPerson(cspmongaeraPerson);

            PersonAPI tell = Global.getSector().getImportantPeople().getPerson("tell");
            if (tell != null) {
                tell.setImportance(PersonImportance.HIGH);
                tell.setPostId("militaryAdministrator");
                tell.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfc_tell"));
                market.getCommDirectory().addPerson(tell, 0);
                market.addPerson(tell);
            }

            // ZZ Top's Missing Band Member
            PersonAPI feznormanPerson = Global.getFactory().createPerson();
            feznormanPerson.setId(feznorman);
            feznormanPerson.setFaction(Factions.TRITACHYON);
            feznormanPerson.setGender(FullName.Gender.MALE);
            feznormanPerson.setRankId(Ranks.CITIZEN);
            feznormanPerson.setPostId(Ranks.POST_INVESTOR);
            feznormanPerson.setImportance(PersonImportance.HIGH);
            feznormanPerson.getName().setFirst("Norman");
            feznormanPerson.getName().setLast("Maxinov");
            feznormanPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "feznorman"));
            market.getCommDirectory().addPerson(feznormanPerson, 3);
            market.addPerson(feznormanPerson);
            market.getCommDirectory().getEntryForPerson(feznormanPerson).setHidden(true);
            ip.addPerson(feznormanPerson);

        }

        market = Global.getSector().getEconomy().getMarket("volturn");
        if (market != null) {

            SectorEntityToken volturncolony = system.getEntityById("volturn");
            volturncolony.getMarket().getIndustry(Industries.AQUACULTURE).setSpecialItem(new SpecialItemData("sfc_aquaticstimulator", null));
            volturncolony.getMarket().addIndustry("sfclobsterresort");

            // sunny flower
            PersonAPI sfcfleuresPerson = Global.getFactory().createPerson();
            sfcfleuresPerson.setId(sfcfleures);
            sfcfleuresPerson.setFaction(Factions.DIKTAT);
            sfcfleuresPerson.setGender(FullName.Gender.FEMALE);
            sfcfleuresPerson.setRankId(Ranks.SPACE_ADMIRAL);
            sfcfleuresPerson.setPostId("sfcadvertchief");
            sfcfleuresPerson.setImportance(PersonImportance.HIGH);
            sfcfleuresPerson.getName().setFirst("Lumi");
            sfcfleuresPerson.getName().setLast("Fleures");
            sfcfleuresPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcfleures"));
            sfcfleuresPerson.addTag(Tags.CONTACT_TRADE);
            sfcfleuresPerson.setVoice(Voices.OFFICIAL);
            sfcfleuresPerson.getStats().setSkillLevel("sfc_hardwork", 1);
            market.setAdmin(sfcfleuresPerson);
            market.getCommDirectory().addPerson(sfcfleuresPerson, 0);
            market.addPerson(sfcfleuresPerson);
            ip.addPerson(sfcfleuresPerson);

            // needs coffee
            PersonAPI sfcjenkinsPerson = Global.getFactory().createPerson();
            sfcjenkinsPerson.setId(sfcjenkins);
            sfcjenkinsPerson.setFaction(Factions.DIKTAT);
            sfcjenkinsPerson.setGender(FullName.Gender.FEMALE);
            sfcjenkinsPerson.setRankId(Ranks.SPACE_ADMIRAL);
            sfcjenkinsPerson.setPostId("sfcproductionchief");
            sfcjenkinsPerson.setImportance(PersonImportance.HIGH);
            sfcjenkinsPerson.getName().setFirst("Velmarie");
            sfcjenkinsPerson.getName().setLast("Jenkins");
            sfcjenkinsPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcjenkins"));
            sfcjenkinsPerson.addTag(Tags.CONTACT_TRADE);
            sfcjenkinsPerson.setVoice(Voices.OFFICIAL);
            market.getCommDirectory().addPerson(sfcjenkinsPerson, 1);
            market.addPerson(sfcjenkinsPerson);
            ip.addPerson(sfcjenkinsPerson);

            // lober
            PersonAPI sfcvolturnyLobster = Global.getFactory().createPerson();
            sfcvolturnyLobster.setId(sfcvolturny);
            sfcvolturnyLobster.setFaction(Factions.DIKTAT);
            sfcvolturnyLobster.setGender(FullName.Gender.MALE);
            sfcvolturnyLobster.setRankId(Ranks.CITIZEN);
            sfcvolturnyLobster.setPostId(Ranks.POST_UNKNOWN);
            sfcvolturnyLobster.setImportance(PersonImportance.VERY_HIGH);
            sfcvolturnyLobster.getName().setFirst("Volturny");
            sfcvolturnyLobster.getName().setLast("");
            sfcvolturnyLobster.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcvolturny"));


            market.getCommDirectory().addPerson(sfcvolturnyLobster);
            market.getCommDirectory().getEntryForPerson(sfcvolturnyLobster).setHidden(true);
            market.addPerson(sfcvolturnyLobster);
            ip.addPerson(sfcvolturnyLobster);

            // hey fonzi
            PersonAPI sfcfonzPerson = Global.getFactory().createPerson();
            sfcfonzPerson.setId(sfcfonz);
            sfcfonzPerson.setFaction(Factions.LIONS_GUARD);
            sfcfonzPerson.setGender(FullName.Gender.MALE);
            sfcfonzPerson.setRankId("sfcregmanager");
            sfcfonzPerson.setPostId("sfcregmanager");
            sfcfonzPerson.setImportance(PersonImportance.VERY_HIGH);
            sfcfonzPerson.getName().setFirst("Albert");
            sfcfonzPerson.getName().setLast("Fonziphone");
            sfcfonzPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcfonz"));
            sfcfonzPerson.addTag(Tags.CONTACT_MILITARY);
            sfcfonzPerson.setVoice(Voices.SOLDIER);
            market.getCommDirectory().addPerson(sfcfonzPerson, 0);
            market.addPerson(sfcfonzPerson);
            market.getCommDirectory().getEntryForPerson(sfcfonzPerson).setHidden(true);
            ip.addPerson(sfcfonzPerson);

            PersonAPI sfcyenniPerson = Global.getFactory().createPerson();

            // the fuelest admiral
            sfcyenniPerson.setId(sfcyenni);
            sfcyenniPerson.setFaction(Factions.DIKTAT);
            sfcyenniPerson.setGender(FullName.Gender.FEMALE);
            sfcyenniPerson.setPostId("sfcfleetadmiral");
            sfcyenniPerson.setRankId(Ranks.SPACE_ADMIRAL);
            sfcyenniPerson.setPersonality(Personalities.AGGRESSIVE);
            sfcyenniPerson.setImportance(PersonImportance.HIGH);
            sfcyenniPerson.setVoice(Voices.SOLDIER);
            sfcyenniPerson.getName().setFirst("Ruka");
            sfcyenniPerson.getName().setLast("Yenni");
            sfcyenniPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcyenni"));
            sfcyenniPerson.getStats().setLevel(15);
            sfcyenniPerson.getStats().setSkillLevel("sfc_titan", 2);
            sfcyenniPerson.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
            sfcyenniPerson.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
            sfcyenniPerson.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
            sfcyenniPerson.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
            sfcyenniPerson.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 2);
            sfcyenniPerson.getStats().setSkillLevel(Skills.HELMSMANSHIP, 1);
            sfcyenniPerson.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 1);
            sfcyenniPerson.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 1);
            sfcyenniPerson.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 1);
            sfcyenniPerson.getStats().setSkillLevel(Skills.COORDINATED_MANEUVERS, 1);
            sfcyenniPerson.getStats().setSkillLevel(Skills.CREW_TRAINING, 1);
            sfcyenniPerson.getStats().setSkillLevel(Skills.OFFICER_TRAINING, 1);
            sfcyenniPerson.getStats().setSkillLevel(Skills.SUPPORT_DOCTRINE, 1);
            sfcyenniPerson.getStats().setSkillLevel(Skills.TACTICAL_DRILLS, 1);
            sfcyenniPerson.getStats().setSkillLevel(Skills.OFFICER_MANAGEMENT, 1);
            if (isTNP) {
                sfcyenniPerson.addTag("coff_forcecapture");
                sfcyenniPerson.addTag("coff_prisonerdialog");
            }
            sfcyenniPerson.addTag("rat_dont_allow_for_skills");
            sfcyenniPerson.getMemoryWithoutUpdate().set("$coff_allowedactions", "talk");
            sfcyenniPerson.getMemoryWithoutUpdate().set("$coff_dialogtrigger", "sfcyenni");
            sfcyenniPerson.getMemoryWithoutUpdate().set("$nex_noOfficerDeath", true);
            sfcyenniPerson.getMemoryWithoutUpdate().set("$chatterChar", "sfcyenni");
            ip.addPerson(sfcyenniPerson);
        }

        //the nft starts here
        market = Global.getSector().getEconomy().getMarket("nachiketa");
        if (market != null) {
            PersonAPI nftpononziPerson = Global.getFactory().createPerson();
            nftpononziPerson.setId(nftpononzi);
            nftpononziPerson.setFaction(Factions.HEGEMONY);
            nftpononziPerson.setGender(FullName.Gender.MALE);
            nftpononziPerson.setRankId("nftexecutive");
            nftpononziPerson.setPostId("nftexecutive");
            nftpononziPerson.setImportance(PersonImportance.VERY_HIGH);
            nftpononziPerson.getName().setFirst("Karlos");
            nftpononziPerson.getName().setLast("Pononzi");
            nftpononziPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "nftpononzi"));
            nftpononziPerson.addTag(Tags.CONTACT_TRADE);
            nftpononziPerson.setVoice(Voices.BUSINESS);
            market.getCommDirectory().addPerson(nftpononziPerson, 1);
            market.addPerson(nftpononziPerson);
            ip.addPerson(nftpononziPerson);
        }
        // war is a racket
        market = Global.getSector().getEconomy().getMarket("nortia");
        if (market != null) {
            PersonAPI nftgimletPerson = Global.getFactory().createPerson();
            nftgimletPerson.setId(nftgimlet);
            nftgimletPerson.setFaction(Factions.HEGEMONY);
            nftgimletPerson.setGender(FullName.Gender.MALE);
            nftgimletPerson.setRankId("nftgeneral");
            nftgimletPerson.setPostId("nftgeneral");
            nftgimletPerson.setImportance(PersonImportance.HIGH);
            nftgimletPerson.getName().setFirst("Darington");
            nftgimletPerson.getName().setLast("Gimlet");
            nftgimletPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "nftgimlet"));
            nftgimletPerson.addTag(Tags.CONTACT_MILITARY);
            nftgimletPerson.setVoice(Voices.SOLDIER);
            market.getCommDirectory().addPerson(nftgimletPerson, 1);
            market.addPerson(nftgimletPerson);
            ip.addPerson(nftgimletPerson);
        }

        //no peace for the government
        market = Global.getSector().getEconomy().getMarket("umbra");
        if (market != null) {
            if (market != null) {
                PersonAPI sfcarcPerson = Global.getFactory().createPerson();
                sfcarcPerson.setId(sfcarc);
                sfcarcPerson.setFaction(Factions.PIRATES);
                sfcarcPerson.setGender(FullName.Gender.FEMALE);
                sfcarcPerson.setRankId(Ranks.FREEDOM_FIGHTER);
                sfcarcPerson.setPostId(Ranks.POST_WARLORD);
                sfcarcPerson.setImportance(PersonImportance.VERY_HIGH);
                sfcarcPerson.getName().setFirst("Emiliana");
                sfcarcPerson.getName().setLast("Francisca");
                sfcarcPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfc_arc"));
                sfcarcPerson.addTag(Tags.CONTACT_MILITARY);
                sfcarcPerson.setVoice(Voices.SOLDIER);
                market.getCommDirectory().addPerson(sfcarcPerson, 1);
                market.addPerson(sfcarcPerson);
                ip.addPerson(sfcarcPerson);
            }

            SectorEntityToken umbra = system.getEntityById("umbra");
            umbra.getMarket().getIndustry(Industries.MINING).setSpecialItem(new SpecialItemData("sfc_motemegacondenser", null));
        }

        // bully
        market = Global.getSector().getEconomy().getMarket("epiphany");
        if (market != null) {
            PersonAPI sfcarthurperson = Global.getFactory().createPerson();
            sfcarthurperson.setId(sfcarthur);
            sfcarthurperson.setFaction(Factions.LUDDIC_PATH);
            sfcarthurperson.setGender(FullName.Gender.MALE);
            sfcarthurperson.setRankId(Ranks.BROTHER);
            sfcarthurperson.setPostId(Ranks.POST_TERRORIST);
            sfcarthurperson.setPersonality(Personalities.RECKLESS);
            sfcarthurperson.setImportance(PersonImportance.HIGH);
            sfcarthurperson.getName().setFirst("Beligar");
            sfcarthurperson.getName().setLast("Arthur");
            sfcarthurperson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcarthur"));
            sfcarthurperson.getStats().setLevel(8);
            sfcarthurperson.getStats().setSkillLevel("sfc_luddskill", 2);
            sfcarthurperson.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
            sfcarthurperson.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
            sfcarthurperson.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
            sfcarthurperson.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
            sfcarthurperson.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 2);
            sfcarthurperson.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 1);
            sfcarthurperson.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 1);
            sfcarthurperson.getStats().setSkillLevel(Skills.CREW_TRAINING, 1);
            sfcarthurperson.getStats().setSkillLevel(Skills.TACTICAL_DRILLS, 1);
            if (isTNP) {
                sfcarthurperson.addTag("coff_forcecapture");
                sfcarthurperson.addTag("coff_prisonerdialog");
                sfcarthurperson.getMemoryWithoutUpdate().set("$coff_allowedactions", "talk");
                sfcarthurperson.getMemoryWithoutUpdate().set("$coff_dialogtrigger", "sfcarthur");
            }
            sfcarthurperson.getMemoryWithoutUpdate().set("$nex_noOfficerDeath", true);
            sfcarthurperson.getMemoryWithoutUpdate().set("$chatterChar", "sfcarthur");

            market.getCommDirectory().addPerson(sfcarthurperson);
            market.getCommDirectory().getEntryForPerson(sfcarthurperson).setHidden(true);
            market.addPerson(sfcarthurperson);
            ip.addPerson(sfcarthurperson);
        }

        PersonAPI sec_officer = Global.getSector().getImportantPeople().getPerson("sec_officer");
        if (sec_officer != null) {
            sec_officer.setRankId("sfcjunior");
            sec_officer.setPostId("sfcjunior");
            sec_officer.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcbalashi"));
            sec_officer.addTag(Tags.CONTACT_MILITARY);
        }

        PersonAPI andrada = Global.getSector().getImportantPeople().getPerson("andrada");
        if (andrada != null) {
            andrada.getName().setFirst("Phillip"); //We call him Phillip in this house
            andrada.setImportance(PersonImportance.VERY_HIGH);
            andrada.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcandrada"));
            andrada.getStats().setSkillLevel("sfc_hardwork", 1);
        }

        PersonAPI caden = Global.getSector().getImportantPeople().getPerson("caden");
        if (caden != null) {
            caden.setImportance(PersonImportance.VERY_HIGH);
            caden.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfc_caden"));
            caden.getStats().setLevel(6);
            caden.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 2);
            caden.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 1);
            caden.getStats().setSkillLevel(Skills.FIELD_MODULATION, 1);
            caden.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
            caden.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 1);
            caden.getStats().setSkillLevel(Skills.HELMSMANSHIP, 1);
            caden.addTag("coff_nocapture");
        }

        PersonAPI hyder = Global.getSector().getImportantPeople().getPerson("hyder");
        if (hyder != null) {
            hyder.setImportance(PersonImportance.HIGH);
            hyder.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfc_hyder"));
            hyder.getStats().setLevel(12);
            hyder.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 2);
            hyder.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
            hyder.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
            hyder.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
            hyder.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
            hyder.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 2);
            hyder.getStats().setSkillLevel(Skills.HELMSMANSHIP, 1);
            hyder.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 1);
            hyder.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 1);
            hyder.getStats().setSkillLevel(Skills.COORDINATED_MANEUVERS, 1);
            hyder.getStats().setSkillLevel(Skills.CREW_TRAINING, 1);
            hyder.getStats().setSkillLevel(Skills.SUPPORT_DOCTRINE, 1);
            hyder.addTag("coff_nocapture");
        }
        PersonAPI macario = Global.getSector().getImportantPeople().getPerson("macario");
        if (macario != null) {
            macario.setImportance(PersonImportance.VERY_HIGH);
            macario.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfc_macario"));
        }

        PersonAPI ram = Global.getSector().getImportantPeople().getPerson("ram");
        if (ram != null) {
            ram.setImportance(PersonImportance.LOW);
            ram.setPostId("sfccompliance");
            ram.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfc_ram"));
        }
        return null;
    }
}