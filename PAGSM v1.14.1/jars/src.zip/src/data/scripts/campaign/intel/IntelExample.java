/*package assortment_of_things;


import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.*;
import java.util.LinkedHashSet;
import java.util.Set;

public class IntelExample extends BaseIntelPlugin {

    PersonAPI person;

    public IntelExample(PersonAPI person) {
        this.person = person;


    }

    @Override
    protected String getName() {
        return "Person: " + person.getNameString();
    }

    @Override
    protected void addBulletPoints(TooltipMakerAPI info, ListInfoMode mode, boolean isUpdate, Color tc, float initPad) {

        Color gray = Misc.getGrayColor();

        info.addSpacer(3f);
        info.addPara("Level: " + person.getStats().getLevel() , 0f, gray, gray);
        info.addPara("Gender: " + person.getGender().name().toLowerCase() ,0f, gray, gray);
    }

    @Override
    public void createSmallDescription(TooltipMakerAPI info, float width, float height) {

        String portraitPath = person.getPortraitSprite();

        info.addSpacer(10f);
        TooltipMakerAPI imageTooltip = info.beginImageWithText(portraitPath, 64f);
        imageTooltip.addPara("An example tooltip attached to an image.", 0f);
        info.addImageWithText(0f);

        info.addSpacer(10f);

        info.addPara("An Example intel window", 0f);

    }

    @Override
    public String getIcon() {
        return person.getPortraitSprite();
    }

    @Override
    public Set<String> getIntelTags(SectorMapAPI map) {
        Set<String> tags = new LinkedHashSet<String>();

        tags.add("Characters");

        return tags;
    }
}
*/