package com.fs.starfarer.api.impl.campaign.intel.events;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.MapParams;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.UIPanelAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.*;
import java.util.List;

public class SFCStandardActivityCause extends SindrianDiktatStandardActivityCause {
    public SFCStandardActivityCause(HostileActivityEventIntel intel) {
        super(intel);
    }

    @Override
    public TooltipMakerAPI.TooltipCreator getTooltip() {
        return new BaseFactorTooltip() {
            @Override
            public void createTooltip(TooltipMakerAPI tooltip, boolean expanded, Object tooltipParam) {
                float opad = 10f;

                Color h = Misc.getHighlightColor();
                Color tc = Misc.getTextColor();

                tooltip.addPara("Your colony production of fuel is high enough for the Sindrian Fuel Company - "
                        + "which idealizes itself as the sole authority of fuel production - to take notice.", 0f);

                List<TriTachyonStandardActivityCause.CompetitorData> comp = computePlayerCompetitionData();
                FactionAPI player = Global.getSector().getFaction(Factions.PLAYER);

                tooltip.beginTable(player, 20f, "Commodity", getTooltipWidth(tooltipParam) - 150f, "Production", 150f);
                for (final TriTachyonStandardActivityCause.CompetitorData data : comp) {
                    tooltip.addRow(Alignment.LMID, tc, Misc.ucFirst(data.spec.getLowerCaseName()),
                            Alignment.MID, h, "" + (int) data.competitorMaxProd);
                }
                tooltip.addTable("", 0, opad);
                tooltip.addSpacer(5f);

                tooltip.addPara("Event progress is based on maximum fuel production. "
                                + "%s below %s per colony should be enough to divert "
                                + "the Fuel Company's attention.", opad,
                        h, "Reducing production levels ", "" + MIN_COMPETITOR_PRODUCTION);

                tooltip.addPara("Knocking the Fuel Company out of the fuel production game also an option. Much of "
                                + "their fuel production depends on a Domain-era Synchrotron Core installed in "
                                + "their production facilities on Sindria.", opad,
                        h, "Synchrotron Core");

                MarketAPI sindria = SindrianDiktatHostileActivityFactor.getSindria(false);
                if (sindria != null && sindria.getStarSystem() != null) {
                    MapParams params = new MapParams();
                    params.showSystem(sindria.getStarSystem());
                    float w = tooltip.getWidthSoFar();
                    float ht = Math.round(w / 1.6f);
                    params.positionToShowAllMarkersAndSystems(true, Math.min(w, ht));
                    UIPanelAPI map = tooltip.createSectorMap(w, ht, params, sindria.getName() + " (" + sindria.getStarSystem().getNameWithLowercaseTypeShort() + ")");
                    tooltip.addCustom(map, opad);
                }
            }
        };
    }
}
