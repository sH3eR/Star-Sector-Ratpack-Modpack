/*package com.fs.starfarer.api.impl.campaign.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.util.Misc;

import javax.xml.stream.Location;
import java.util.List;
import java.util.Map;

public class sfcGateHaulerCheck extends BaseCommandPlugin {

    public static SectorEntityToken gatehauler = Global.getSector().getMemoryWithoutUpdate().getEntity("derelict_gatehauler");
    protected InteractionDialogAPI dialog;
    protected Map<String, MemoryAPI> memoryMap;

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
        this.dialog = dialog;
        this.memoryMap = memoryMap;
        final MemoryAPI memory = getEntityMemory(memoryMap);
        final List<LocationAPI> starSystem = Global.getSector().getAllLocations();
        String cmd = null;

        cmd = params.get(0).getString(memoryMap);
        String param = null;
        if (params.size() > 1) {
            param = params.get(1).getString(memoryMap);
        }

        final TextPanelAPI text = dialog.getTextPanel();
        for (LocationAPI location = gatehauler.getContainingLocation()) {
                if (location.(starSystem(param))) {
                    return true;
                }
                }
            }
        }
        return false;
    }
}*/