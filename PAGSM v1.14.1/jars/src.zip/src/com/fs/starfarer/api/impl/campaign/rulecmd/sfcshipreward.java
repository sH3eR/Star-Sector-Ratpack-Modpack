/*package com.fs.starfarer.api.impl.campaign.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.rulecmd.sfcMemoryManager;
import com.fs.starfarer.api.util.Misc;

import java.util.List;
import java.util.Map;

public class sfcshipreward extends BaseCommandPlugin{
    static String ref_String = "$sfc_stringRef";
    static String ref_Faction = "$sfc_factionRef";
    static String ref_Ship = "$sfc_shipRef";
    static String ref_Name = "$sfc_nameRef";
    static String ref_Price = "$sfc_priceRef";

    public sfcshipreward(){
    }

    public sfcMemoryManager getMemoryManager () {
        MemoryAPI maimMem = Global.getSector().getMemoryWithoutUpdate();
        sfcMemoryManager mem = (sfcMemoryManager)mainMem.get(ref_String);
        return mem;
    }

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
        return false;
    }
}
*/