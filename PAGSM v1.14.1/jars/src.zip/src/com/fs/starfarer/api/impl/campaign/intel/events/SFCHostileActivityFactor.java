package com.fs.starfarer.api.impl.campaign.intel.events;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.comm.IntelInfoPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.*;

public class SFCHostileActivityFactor extends SindrianDiktatHostileActivityFactor {

    public SFCHostileActivityFactor(HostileActivityEventIntel intel) {
        super(intel);
    }

    @Override
    public String getDesc(BaseEventIntel intel) {
        return "Sindrian Fuel Company";
    }

    @Override
    public String getNameForThreatList(boolean first) {
        return "Sindrian Fuel Company";
    }

    @Override
    public TooltipMakerAPI.TooltipCreator getMainRowTooltip(BaseEventIntel intel) {
        return new BaseFactorTooltip() {
            public void createTooltip(TooltipMakerAPI tooltip, boolean expanded, Object tooltipParam) {
                float opad = 10f;
                tooltip.addPara("You've attracted the attention of the Sindrian Fuel Company.", 0f);

                tooltip.addPara("Sindrian raider fleets have been sighted in your space, "
                        + "attacking trade fleets regardless of their factional allegiance.", opad);
            }
        };
    }

    @Override
    public void addBulletPointForEvent(HostileActivityEventIntel intel, BaseEventIntel.EventStageData stage, TooltipMakerAPI info,
                                       IntelInfoPlugin.ListInfoMode mode, boolean isUpdate, Color tc, float initPad) {
        Color c = Global.getSector().getFaction(Factions.DIKTAT).getBaseUIColor();
        info.addPara("Impending Sindrian Fuel Company attack", initPad, tc, c, "Sindrian Fuel Company");
    }

    @Override
    public void addBulletPointForEventReset(HostileActivityEventIntel intel, BaseEventIntel.EventStageData stage, TooltipMakerAPI info,
                                            IntelInfoPlugin.ListInfoMode mode, boolean isUpdate, Color tc, float initPad) {
        info.addPara("Sindrian Fuel Company attack averted", tc, initPad);
    }

    @Override
    public void addStageDescriptionForEvent(HostileActivityEventIntel intel, BaseEventIntel.EventStageData stage, TooltipMakerAPI info) {
        float small = 0f;
        float opad = 10f;

        small = 8f;

        Color c = Global.getSector().getFaction(Factions.DIKTAT).getBaseUIColor();

        Color h = Misc.getHighlightColor();
        info.addPara("You've received intel that the Sindrian Fuel Company is planning an attack to "
                        + "saturation-bombard your fuel production facilities.",
                small, Misc.getNegativeHighlightColor(), "saturation-bombard");

//		LabelAPI label = info.addPara("If the attack is defeated, your standing with the Hegemony "
//				+ "and the independents will increase substantially, and the Diktat will likely abandon "
//				+ "further efforts against you. In addition, your ability to export fuel will be improved.",
//				opad);
//		label.setHighlight("Hegemony", "independents", "increase substantially", "Diktat",
//				"ability to export fuel will be improved");
//		label.setHighlightColors(Global.getSector().getFaction(Factions.HEGEMONY).getBaseUIColor(),
//				Global.getSector().getFaction(Factions.INDEPENDENT).getBaseUIColor(),
//				Misc.getPositiveHighlightColor(),
//				Global.getSector().getFaction(Factions.DIKTAT).getBaseUIColor(),
//				Misc.getPositiveHighlightColor());

        LabelAPI label = info.addPara("If the attack is defeated the Fuel Company will likely abandon "
                        + "further efforts against you, and your ability to export fuel will be improved.",
                opad);
        label.setHighlight("Fuel Company",
                "export fuel", "improved");
        label.setHighlightColors(
                Global.getSector().getFaction(Factions.DIKTAT).getBaseUIColor(),
                Misc.getPositiveHighlightColor(),
                Misc.getPositiveHighlightColor());

        c = Global.getSector().getFaction(Factions.DIKTAT).getBaseUIColor();
        stage.beginResetReqList(info, true, "crisis", opad);
        info.addPara("You go to %s and make an agreement with the Fuel Company", 0f, c, "Sindria");
        info.addPara("%s is tactically bombarded", 0f, c, "Sindria");
        info.addPara("Fuel production on %s is significantly disrupted", 0f, c, "Sindria");
        stage.endResetReqList(info, false, "crisis", -1, -1);

        addBorder(info, Global.getSector().getFaction(Factions.DIKTAT).getBaseUIColor());
    }

    @Override
    public String getEventStageIcon(HostileActivityEventIntel intel, BaseEventIntel.EventStageData stage) {
        return Global.getSector().getFaction(Factions.DIKTAT).getCrest();
    }

    @Override
    public TooltipMakerAPI.TooltipCreator getStageTooltipImpl(final HostileActivityEventIntel intel, final BaseEventIntel.EventStageData stage) {
        if (stage.id == HostileActivityEventIntel.Stage.HA_EVENT) {
            return getDefaultEventTooltip("Sindrian Fuel Company attack", intel, stage);
        }
        return null;
    }
}
