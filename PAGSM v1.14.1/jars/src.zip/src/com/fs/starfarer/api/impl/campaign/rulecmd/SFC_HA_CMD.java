package com.fs.starfarer.api.impl.campaign.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.rules.MemKeys;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.intel.SFCFuelDeal;
import com.fs.starfarer.api.impl.campaign.intel.events.*;
import com.fs.starfarer.api.impl.campaign.intel.group.SindrianDiktatPunitiveExpedition;
import com.fs.starfarer.api.util.Misc;

import java.util.List;
import java.util.Map;

public class SFC_HA_CMD extends HA_CMD {
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
        if (dialog == null) return false;

        OptionPanelAPI options = dialog.getOptionPanel();
        TextPanelAPI text = dialog.getTextPanel();
        CampaignFleetAPI pf = Global.getSector().getPlayerFleet();
        other = dialog.getInteractionTarget();
        CargoAPI cargo = pf.getCargo();


        String action = params.get(0).getString(memoryMap);

        MemoryAPI memory = memoryMap.get(MemKeys.LOCAL);
        if (memory == null) return false; // should not be possible unless there are other big problems already


        //MarketAPI market = dialog.getInteractionTarget().getMarket();
        StarSystemAPI system = null;
        if (dialog.getInteractionTarget().getContainingLocation() instanceof StarSystemAPI) {
            system = (StarSystemAPI) dialog.getInteractionTarget().getContainingLocation();
        }


        if ("diktatConcernedByFuelProd".equals(action)) {
            HostileActivityEventIntel intel = HostileActivityEventIntel.get();
            if (intel != null) {
                HostileActivityCause2 cause = intel.getActivityCause(SFCHostileActivityFactor.class, SFCStandardActivityCause.class);
                if (cause instanceof SFCStandardActivityCause) {
                    SFCStandardActivityCause lcCause = (SFCStandardActivityCause) cause;
                    return lcCause.getProgress() > 0;
                }
            }
        } else if ("makeDiktatDeal".equals(action)) {
            if (SFCFuelDeal.get() == null) {
                new SFCFuelDeal(dialog);
            }
        } else if ("printSDDealRepReq".equals(action)) {
            FactionAPI diktat = Global.getSector().getFaction(Factions.DERELICT);
            CoreReputationPlugin.addRequiredStanding(diktat, RepLevel.INHOSPITABLE, null, dialog.getTextPanel(), null, null, 0f, true);
            CoreReputationPlugin.addCurrentStanding(diktat, null, dialog.getTextPanel(), null, null, 0f);
        } else if ("breakSDDeal".equals(action)) {
            if (SFCFuelDeal.get() != null) {
                SFCFuelDeal.get().endAgreement(SFCFuelDeal.AgreementEndingType.BROKEN, dialog);
            }
        }
        return false;
    }


    public static void avertOrEndSFCAttackAsNecessary() {
        SindrianDiktatPunitiveExpedition attack = SindrianDiktatPunitiveExpedition.get();
        if (attack != null) {
            attack.finish(false);
        }

        HostileActivityEventIntel intel = HostileActivityEventIntel.get();
        if (intel != null) {
            HostileActivityEventIntel.HAERandomEventData data = intel.getRollDataForEvent();
            if (data != null && data.factor instanceof SFCHostileActivityFactor) {
                intel.resetHA_EVENT();
            }
        }
    }
}
