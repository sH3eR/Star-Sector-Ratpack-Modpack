package com.fs.starfarer.api.impl.campaign.missions.askonia;

import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.*;

public class SFCUsurpers extends TheUsurpers {

    @Override
    public void addDescriptionForNonEndStage(TooltipMakerAPI info, float width, float height) {
        float opad = 10f;
        Color h = Misc.getHighlightColor();

        //info.addImage(robed_man.getPortraitSprite(), width, 128, opad);

        if (currentStage == Stage.MEET_RAM) {
            info.addPara("Meet Yannick Ram at his safehouse on Volturn. He has a plan to save the Sindrian Fuel Company from itself.", opad);
            addStandardMarketDesc("Ram gave you coordinates to his safehouse " + volturn.getOnOrAt(), volturn, info, opad);
        }
        else if (currentStage == Stage.INTERCEPT_FLEET) {
            info.addPara("Find and intercept a Sindrian Fuel Company patrol fleet led by the 'treasonous' manager. It can be found in the Askonia system.", opad);
        }
        else if (currentStage == Stage.MEET_HYDER) {
            info.addPara("Use the 'treasonous' manager as leverage to gain access to Vice Executive Manager Hyder. She can be found in command of the Askonia System Defense Armada, a large warfleet patrolling the Askonia star system.", opad);
        }
        else if (currentStage == Stage.RETURN_TO_MACARIO) {
            info.addPara("Report back to Macario about your conversation with Hyder.", opad);
            addStandardMarketDesc("Executive Manager Macario is based " + sindria.getOnOrAt(), sindria, info, opad);
        }
        else if (currentStage == Stage.EXTRACT_AGENT) {
            info.addPara("Extract a known double-agent who, while working for Horacio Caden, has betrayed the Sindrian Fuel Company.", opad);
            addStandardMarketDesc("The 'treasonous' double-agent is based " + umbra.getOnOrAt(), umbra, info, opad);
        }
        else if (currentStage == Stage.MEET_CADEN) {
            info.addPara("Use the 'treasonous' agent as leverage to gain access to Grand High Deputy Executor Caden. He can be found in command of the Lion's Guard Grand Armada, a large warfleet patrolling the Askonia star system.", opad);
        }
        else if (currentStage == Stage.AGAIN_WTH_MACARIO) {
            info.addPara("Report back to Macario about your conversation with Caden.", opad);
            addStandardMarketDesc("Executive Manager Macario is based " + sindria.getOnOrAt(), sindria, info, opad);
        }
        else if (currentStage == Stage.EMERGENCY_INTERCEPT) {
            info.addPara("Intercept and assist or capture Macario's agent at the Fringe Jump-point of Askonia.", opad);
        }
        else if (currentStage == Stage.DELIVER_NEWS) {
            info.addPara("Report back to Macario with news of his agent's demise.", opad);
        }
    }

    @Override
    public boolean addNextStepText(TooltipMakerAPI info, Color tc, float pad) {
        Color h = Misc.getHighlightColor();
        if (currentStage == Stage.MEET_RAM) {
            info.addPara("Meet Yannick Ram at his safehouse on Volturn.", tc, pad);
            return true;
        }
        if (currentStage == Stage.INTERCEPT_FLEET) {
            info.addPara("Intercept the traitor's patrol fleet in the Askonia system.", tc, pad);
            return true;
        }
        else if (currentStage == Stage.MEET_HYDER) {
            info.addPara("Speak with Oxana Hyder. She commands the Askonia System Defense Armada.", tc, pad);
            return true;
        }
        else if (currentStage == Stage.RETURN_TO_MACARIO) {
            info.addPara("Talk to Macario, on Sindria, about Hyder.", tc, pad);
            return true;
        }
        else if (currentStage == Stage.EXTRACT_AGENT) {
            info.addPara("Extract the double agent from Umbra.", tc, pad);
            return true;
        }
        else if (currentStage == Stage.MEET_CADEN) {
            info.addPara("Speak with Horacio Caden. He commands the Lion's Guard Grand Armada.", tc, pad);
            return true;
        }
        else if (currentStage == Stage.AGAIN_WTH_MACARIO) {
            info.addPara("Talk to Macario, on Sindria, about Caden.", tc, pad);
            return true;
        }
        else if (currentStage == Stage.EMERGENCY_INTERCEPT) {
            info.addPara("Intercept Macario's agent at the given location.", tc, pad);
            return true;
        }
        else if (currentStage == Stage.DELIVER_NEWS) {
            info.addPara("Return to Macario, on Sindria, with news of his agent's death.", tc, pad);
            return true;
        }
        return false;
    }
}
