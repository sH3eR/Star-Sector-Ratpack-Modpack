package com.fs.starfarer.api.impl.campaign.ids;

public class sfc_items extends Items {
    // new additional colony items because why not
    public static final String AQUATIC_STIMULATOR = "sfc_aquaticstimulator";
    public static final String MOTE_MEGACONDENSER = "sfc_motemegacondenser";
}