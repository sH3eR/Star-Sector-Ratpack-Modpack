package exoticatechnologies.ui.lists.filtered

class ListFilter {
    val filters: List<String> = mutableListOf()
}