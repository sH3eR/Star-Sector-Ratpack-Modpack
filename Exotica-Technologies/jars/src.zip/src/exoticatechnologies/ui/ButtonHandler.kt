package exoticatechnologies.ui

open class ButtonHandler {
    open fun highlighted() {}

    open fun unhighlighted() {}

    open fun checked() {}
}