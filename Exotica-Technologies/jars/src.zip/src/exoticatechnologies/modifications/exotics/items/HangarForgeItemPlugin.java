package exoticatechnologies.modifications.exotics.items;

import exoticatechnologies.modifications.exotics.ExoticSpecialItemPlugin;

public class HangarForgeItemPlugin extends ExoticSpecialItemPlugin {
    @Override
    public String getModId() {
        return "HangarForge";
    }
}
