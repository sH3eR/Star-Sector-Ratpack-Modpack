package exoticatechnologies.modifications.exotics.items;

import exoticatechnologies.modifications.exotics.ExoticSpecialItemPlugin;

public class EqualizerCoreItemPlugin extends ExoticSpecialItemPlugin {
    @Override
    public String getModId() {
        return "EqualizerCore";
    }
}
