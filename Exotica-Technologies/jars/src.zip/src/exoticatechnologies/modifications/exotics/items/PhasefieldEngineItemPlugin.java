package exoticatechnologies.modifications.exotics.items;

import exoticatechnologies.modifications.exotics.ExoticSpecialItemPlugin;

public class PhasefieldEngineItemPlugin extends ExoticSpecialItemPlugin {
    @Override
    public String getModId() {
        return "PhasefieldEngine";
    }
}
