package exoticatechnologies.modifications.exotics.items;

import exoticatechnologies.modifications.exotics.ExoticSpecialItemPlugin;

public class SpooledFeedersItemPlugin extends ExoticSpecialItemPlugin {
    @Override
    public String getModId() {
        return "SpooledFeeders";
    }
}
