//By Tartiflette

package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import java.awt.Color;
import java.util.Random;
import org.lazywizard.lazylib.FastTrig;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

public class MSS_quicksilverEffect implements EveryFrameWeaponEffectPlugin {

    private boolean runOnce = false, boost = false, activation = true, pulse = false;
    private ShipSystemAPI system;
    private ShipAPI ship;
    private final String ID = "MSS_quicksilverBoost";

    private float dX, dY, bX, bY, DirDoors = 0, DirGlow = 0;


    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {

        if (engine.isPaused()) {
            return;
        }

        if (!runOnce) {
            runOnce = true;
            ship = weapon.getShip();
            system = ship.getSystem();
        }

        //PHASE BOOST
        if (ship.isPhased()) {
            if (!boost) {
                boost = true;
                ship.getMutableStats().getMaxSpeed().modifyFlat(ID, 100);
                ship.getMutableStats().getAcceleration().modifyMult(ID, 4);
                ship.getMutableStats().getDeceleration().modifyMult(ID, 4);
                ship.getMutableStats().getMaxTurnRate().modifyMult(ID, 6);
                ship.getMutableStats().getTurnAcceleration().modifyMult(ID, 6);
            }
        } else if (boost) {
            boost = false;
            ship.getMutableStats().getMaxSpeed().unmodify(ID);
            ship.getMutableStats().getAcceleration().unmodify(ID);
            ship.getMutableStats().getDeceleration().unmodify(ID);
            ship.getMutableStats().getMaxTurnRate().unmodify(ID);
            ship.getMutableStats().getTurnAcceleration().unmodify(ID);
        }
    }
}
