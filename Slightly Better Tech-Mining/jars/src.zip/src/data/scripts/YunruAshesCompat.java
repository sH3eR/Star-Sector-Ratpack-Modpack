package data.scripts;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.Global;

public class YunruAshesCompat {
    public static boolean isResearched(String id) {
        Map<String,Boolean> researchSaved = (HashMap<String, Boolean>) Global.getSector().getPersistentData().get("researchsaved");
        return researchSaved != null ? researchSaved.get(id) : false;
    }
}
