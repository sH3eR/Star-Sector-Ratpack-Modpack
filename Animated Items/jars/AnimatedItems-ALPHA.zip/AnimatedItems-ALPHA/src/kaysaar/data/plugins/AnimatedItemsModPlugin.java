package kaysaar.data.plugins;

import com.fs.starfarer.api.BaseModPlugin;

public class AnimatedItemsModPlugin extends BaseModPlugin {

}
