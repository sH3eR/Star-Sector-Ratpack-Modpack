package kaysaar.data.scripts.campaign.econ.items;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.impl.items.GenericSpecialItemPlugin;
import com.fs.starfarer.api.graphics.SpriteAPI;
import kaysaar.data.scripts.campaign.econ.items.models.AlphaUtil;
import kaysaar.data.scripts.campaign.econ.items.models.Particle;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Vector2f;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class AnimatedNanoforgePlugin extends GenericSpecialItemPlugin {
    public static final Color PING_COLOR = new Color(119, 255, 0, 255);
    public static final Color PING_COLOR2 = new Color(187, 253, 130, 255);
    private final List<Particle> particles = new ArrayList<>();
    private final Random random = new Random();

    private  AlphaUtil alphaUtil;

    // Variables for easy configuration
    private final float particleFrequency = 0.9f;   // Frequency of particles spawning
    private final float particleStartXOffset = 0.5f;  // Offset for the X starting position of particles (as a fraction of width)
    private final float particleStartYOffset = -30;   // Offset for the Y starting position of particles
    private final float particleSpawnWidth = 18.0f;  // Width over which particles can spawn (as a fraction of width)
    private final float particleDirectionMin = 190f;  // Minimum angle for particle direction
    private final float particleDirectionRange = 70f;  // Range for randomizing particle direction

    @Override
    public void init(CargoStackAPI stack) {
        super.init(stack);
        this.alphaUtil = new AlphaUtil(0.4f, 0.2f, 0.6f, 0.005f);
    }

    private void spawnParticle(float x, float y) {
        float angle = particleDirectionMin + random.nextFloat() * particleDirectionRange;  // Randomize the angle around the specified range
        float speedX = 20f + random.nextFloat() * 20f;  // Randomize speed in X direction
        float speedY = 5f + random.nextFloat() * 10f;  // Lower Y speed
        Vector2f velocity = new Vector2f((float) Math.cos(Math.toRadians(angle)) * speedX, (float) Math.sin(Math.toRadians(angle)) * speedY);
        float life = 0.25f + random.nextFloat();  // Randomize life duration more
        Color color = PING_COLOR2; // Randomize color
        SpriteAPI sprite = Global.getSettings().getSprite("rendering","particle_"+random.nextInt(12));
        particles.add(new Particle(new Vector2f(x, y), velocity, life, color,sprite));
    }

    @Override
    public void render(float x, float y, float w, float h, float alphaMult, float glowMult, SpecialItemRendererAPI renderer) {
        Color glowColor = PING_COLOR;
        float centerX = x + w * 0.5f;
        float centerY = y + h * 0.5f;

        // Static sprite rendering

        // Particle spawning
        if (random.nextFloat() < particleFrequency) {  // Adjust particle spawning frequency
            float spawnX = centerX - 12 + (random.nextFloat() * particleSpawnWidth - particleSpawnWidth / 2);  // Randomize X spawn position over the specified width
            float spawnY = centerY - 1 + particleStartYOffset;  // Adjust Y spawn position
            spawnParticle(spawnX, spawnY);
        }

        // Particle updating and rendering
        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_BLEND);
        int blendFunc1 = GL11.GL_SRC_ALPHA;
        int blendFunc2 = GL11.GL_ONE_MINUS_SRC_ALPHA;
        GL11.glBlendFunc(blendFunc1, blendFunc2);

        Iterator<Particle> iterator = particles.iterator();
        while (iterator.hasNext()) {
            Particle particle = iterator.next();
            if (!particle.isAlive()) {
                iterator.remove();
                continue;
            }
            particle.particleSprite.bindTexture();
            particle.update(0.005f);

            float particleAlpha = particle.getAlpha(7f);
            GL11.glColor4f(particle.color.getRed() / 255f, particle.color.getGreen() / 255f, particle.color.getBlue() / 255f, particleAlpha);

            float particleX = particle.position.x;
            float particleY = particle.position.y;
            float particleSize = 10f;

            GL11.glBegin(GL11.GL_QUADS);
            GL11.glTexCoord2f(0, 0);
            GL11.glVertex2f(particleX - particleSize / 2, particleY - particleSize / 2);
            GL11.glTexCoord2f(1, 0);
            GL11.glVertex2f(particleX + particleSize / 2, particleY - particleSize / 2);
            GL11.glTexCoord2f(1, 1);
            GL11.glVertex2f(particleX + particleSize / 2, particleY + particleSize / 2);
            GL11.glTexCoord2f(0, 1);
            GL11.glVertex2f(particleX - particleSize / 2, particleY + particleSize / 2);
            GL11.glEnd();
        }

        GL11.glPopMatrix();
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);

        SpriteAPI staticSprite = Global.getSettings().getSprite("rendering", "nanoforge_glow_2");
        staticSprite.setColor(glowColor);
        staticSprite.setAdditiveBlend();
        staticSprite.setAlphaMult(alphaUtil.getAlphaMult());
        staticSprite.renderAtCenter(centerX, centerY);
    }
}
