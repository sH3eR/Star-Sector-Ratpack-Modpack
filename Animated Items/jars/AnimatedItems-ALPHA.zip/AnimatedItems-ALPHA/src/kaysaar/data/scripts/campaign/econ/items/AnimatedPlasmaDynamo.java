package kaysaar.data.scripts.campaign.econ.items;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.impl.items.GenericSpecialItemPlugin;
import com.fs.starfarer.api.graphics.SpriteAPI;
import kaysaar.data.scripts.campaign.econ.items.models.AlphaUtil;
import kaysaar.data.scripts.campaign.econ.items.models.Lightning;
import kaysaar.data.scripts.misc.AoTDMisc;

import java.awt.*;
import java.util.Random;

public class AnimatedPlasmaDynamo extends GenericSpecialItemPlugin {
    private static final Color LIGHTNING_COLOR = new Color(122, 199, 255, 255);
    private static final Color LIGHTNING_COLOR2 = new Color(37, 74, 254, 255);
    private static final float LIGHTNING_WIDTH = 1.5f;
    private static final float LIGHTNING_LIFETIME = 0.2f;
    private static final float SPAWN_CHANCE = 0.25f;
    private final Random random = new Random();
    private final Lightning lightning = new Lightning(LIGHTNING_COLOR, LIGHTNING_WIDTH, LIGHTNING_LIFETIME, 10);
    private AlphaUtil alphaUtil;
    private AlphaUtil alphaUtil2;
    private AlphaUtil alphaUtil3;

    @Override
    public void init(CargoStackAPI stack) {
        super.init(stack);
        this.alphaUtil = new AlphaUtil(0.4f, 0.4f, 0.95f, 0.005f);
        this.alphaUtil2 = new AlphaUtil(0.5f, 0.4f, 0.95f, 0.005f);
        this.alphaUtil3 = new AlphaUtil(0.6f, 0.4f, 0.95f, 0.005f);
    }

    @Override
    public void render(float x, float y, float w, float h, float alphaMult, float glowMult, SpecialItemRendererAPI renderer) {
        float centerX = x + w * 0.5f;
        float centerY = y + h * 0.5f;

        if (random.nextFloat() < SPAWN_CHANCE) {
            float length = 30; // Example length, you can adjust this
            float angleMin = 180; // Minimum angle
            float angleMax = 200; // Maximum angle
            float dif = 20;
            for (int i = 0; i < 9; i++) {
                lightning.spawnLightningArc(centerX, centerY + 10, length - i, angleMin - (dif * i), angleMax - (dif * i));
            }
            lightning.spawnLightningArc(centerX, centerY + 10, length, 350, 360);
            lightning.spawnLightningArc(centerX, centerY + 10, length, 350, 360);
            lightning.spawnLightningArc(centerX, centerY + 10, length, 0, 20);
        }

        AoTDMisc.startStencil(x, y + 8, w - 20, h);
        SpriteAPI lightningSprite = Global.getSettings().getSprite("rendering", "lightning_bolt");
        lightning.render(0.9f, lightningSprite);
        AoTDMisc.endStencil();
        SpriteAPI staticSprite = Global.getSettings().getSprite("rendering", "plasma_1");
        staticSprite.setColor(LIGHTNING_COLOR2);
        staticSprite.setAdditiveBlend();
        staticSprite.setAlphaMult(alphaUtil.getAlphaMult());
        staticSprite.renderAtCenter(centerX, centerY);
        SpriteAPI staticSprite2 = Global.getSettings().getSprite("rendering", "plasma_2");
        staticSprite2.setColor(LIGHTNING_COLOR2);
        staticSprite2.setAdditiveBlend();
        staticSprite2.setAlphaMult(alphaUtil2.getAlphaMult());
        staticSprite2.renderAtCenter(centerX, centerY);
        SpriteAPI staticSprite3 = Global.getSettings().getSprite("rendering", "plasma_3");
        staticSprite3.setColor(LIGHTNING_COLOR2);
        staticSprite3.setAdditiveBlend();
        staticSprite3.setAlphaMult(alphaUtil3.getAlphaMult());
        staticSprite3.renderAtCenter(centerX, centerY);

        staticSprite3.setAdditiveBlend();
        staticSprite3.setAlphaMult(alphaUtil3.getAlphaMult());
        staticSprite3.renderAtCenter(centerX, centerY);
        staticSprite2.setAdditiveBlend();
        staticSprite2.setAlphaMult(alphaUtil2.getAlphaMult());
        staticSprite2.renderAtCenter(centerX, centerY);

        staticSprite.setAdditiveBlend();
        staticSprite.setAlphaMult(alphaUtil.getAlphaMult());
        staticSprite.renderAtCenter(centerX, centerY);
    }
}
