package kaysaar.data.scripts.campaign.econ.items;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.impl.items.GenericSpecialItemPlugin;
import com.fs.starfarer.api.graphics.SpriteAPI;
import kaysaar.data.scripts.campaign.econ.items.models.AlphaUtil;
import kaysaar.data.scripts.campaign.econ.items.models.Particle;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class AnimatedOrbitalLamp extends GenericSpecialItemPlugin {
    private final List<Particle> particles = new ArrayList<>();
    private final Random random = new Random();
    private final float particleFrequency = 0.1f;  // Frequency of particles spawning
    private final float particleDirectionMin = 100f;  // Minimum angle for particle direction
    private final float particleDirectionRange = 30f;  // Range for randomizing particle direction
    private final float particleSpeedMin = 2f;  // Minimum speed of particles
    private final float particleSpeedRange = 4f;  // Range for randomizing particle speed
        AlphaUtil alphaUtil;
    @Override
    public void init(CargoStackAPI stack) {
        super.init(stack);
        this.alphaUtil = new AlphaUtil(0.5f, 0.5f, 0.9f, 0.008f);
    }



    @Override
    public void render(float x, float y, float w, float h, float alphaMult, float glowMult, SpecialItemRendererAPI renderer) {
        Color glowColor = new Color(252, 162, 120, 255);
        float centerX = x + w * 0.5f;
        float centerY = y + h * 0.5f;
        SpriteAPI staticSprite = Global.getSettings().getSprite("rendering", "lamp");
        staticSprite.setColor(glowColor);
        staticSprite.setAdditiveBlend();
        staticSprite.setAlphaMult(alphaUtil.getAlphaMult());
        staticSprite.renderAtCenter(centerX, centerY);
    }
}
