package kaysaar.data.scripts.campaign.econ.items;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.impl.items.GenericSpecialItemPlugin;
import com.fs.starfarer.api.graphics.SpriteAPI;
import kaysaar.data.scripts.campaign.econ.items.models.AlphaUtil;

import java.awt.Color;

public class AnimatedSynchotron extends GenericSpecialItemPlugin {
    private AlphaUtil alphaUtil;

    @Override
    public void init(CargoStackAPI stack) {
        super.init(stack);
        this.alphaUtil = new AlphaUtil(0.5f, 0.4f, 0.95f, 0.01f, true, 1.1f); // Enable heartbeat mode with a pause duration of 1 second
    }

    @Override
    public void render(float x, float y, float w, float h, float alphaMult, float glowMult, SpecialItemRendererAPI renderer) {
        float centerX = x + w * 0.5f;
        float centerY = y + h * 0.5f;

        // Static sprite rendering
        SpriteAPI staticSprite = Global.getSettings().getSprite("rendering", "synchotron");
        staticSprite.setColor(new Color(252, 24, 88, 255));
        staticSprite.setAdditiveBlend();
        staticSprite.setAlphaMult(alphaUtil.getAlphaMult());
        staticSprite.renderAtCenter(centerX, centerY);
        staticSprite.renderAtCenter(centerX, centerY);
    }
}
