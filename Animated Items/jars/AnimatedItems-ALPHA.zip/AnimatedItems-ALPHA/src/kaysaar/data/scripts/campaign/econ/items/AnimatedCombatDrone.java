package kaysaar.data.scripts.campaign.econ.items;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.impl.items.GenericSpecialItemPlugin;
import com.fs.starfarer.api.graphics.SpriteAPI;
import kaysaar.data.scripts.campaign.econ.items.models.AlphaUtil;

import java.awt.*;

public class AnimatedCombatDrone extends GenericSpecialItemPlugin {

    AlphaUtil alphaUtil;
    AlphaUtil blinking;

    @Override
    public void init(CargoStackAPI stack) {
        super.init(stack);
        this.alphaUtil = new AlphaUtil(0.4f, 0.4f, 0.8f, 0.002f);
        this.blinking = new AlphaUtil(0.1f, 0.1f, 0.7f, 0.0005f);
    }

    @Override
    public void render(float x, float y, float w, float h, float alphaMult, float glowMult, SpecialItemRendererAPI renderer) {
        Color glowColor = new Color(252, 109, 42, 255);
        Color glowColor2 = new Color(243, 57, 79, 255);
        float centerX = x + w * 0.5f;
        float centerY = y + h * 0.5f;
        SpriteAPI staticSprite = Global.getSettings().getSprite("rendering", "combat_1");
        staticSprite.setColor(glowColor);
        staticSprite.setAdditiveBlend();
        staticSprite.setAlphaMult(alphaUtil.getAlphaMult());
        staticSprite.renderAtCenter(centerX, centerY);
        SpriteAPI staticSprite2 = Global.getSettings().getSprite("rendering", "combat_2");
        staticSprite2.setColor(glowColor2);
        staticSprite2.setAdditiveBlend();
        staticSprite2.setAlphaMult(blinking.getAlphaMult());
        staticSprite2.renderAtCenter(centerX-2, centerY+5);
        staticSprite2.setAlphaMult(blinking.getAlphaMult()/2);
        staticSprite2.renderAtCenter(centerX-2, centerY+5);
    }
}
