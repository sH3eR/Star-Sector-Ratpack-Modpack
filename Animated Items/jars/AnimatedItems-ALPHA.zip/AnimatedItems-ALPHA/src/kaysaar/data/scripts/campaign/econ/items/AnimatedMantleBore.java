package kaysaar.data.scripts.campaign.econ.items;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.impl.items.GenericSpecialItemPlugin;
import com.fs.starfarer.api.graphics.SpriteAPI;

public class AnimatedMantleBore extends GenericSpecialItemPlugin {
    float angleFirst = 0f;
    float angleSecond = 0f;

    public void moveBothAngles(){
        angleFirst+=0.1f;
        angleSecond-=0.2f;
        if(Math.abs(angleFirst)>360){
            angleFirst =0;
        }
        if(Math.abs(angleSecond)>360){
            angleSecond =0;
        }
    }
    @Override
    public void render(float x, float y, float w, float h, float alphaMult, float glowMult, SpecialItemRendererAPI renderer) {
        super.render(x, y, w, h, alphaMult, glowMult, renderer);
        float centerX = x + w * 0.5f;
        float centerY = y + h * 0.5f;
        SpriteAPI firstSptire = Global.getSettings().getSprite("rendering","mantle_bore_1");
        SpriteAPI secondSprite =  Global.getSettings().getSprite("rendering","mantle_bore_2");
        secondSprite.setAngle(angleSecond);
        firstSptire.renderAtCenter(centerX-17,centerY-10);
        secondSprite.renderAtCenter(centerX-17,centerY-12);
        moveBothAngles();
    }
}
