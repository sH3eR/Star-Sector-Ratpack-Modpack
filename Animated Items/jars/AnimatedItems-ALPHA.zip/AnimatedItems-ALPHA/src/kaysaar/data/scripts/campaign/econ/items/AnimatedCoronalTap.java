package kaysaar.data.scripts.campaign.econ.items;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.impl.items.GenericSpecialItemPlugin;
import com.fs.starfarer.api.graphics.SpriteAPI;
import kaysaar.data.scripts.campaign.econ.items.models.AlphaUtil;
import kaysaar.data.scripts.campaign.econ.items.models.Lightning;
import kaysaar.data.scripts.misc.AoTDMisc;


import java.awt.Color;
import java.util.Random;

public class AnimatedCoronalTap extends GenericSpecialItemPlugin {

    private static final Color LIGHTNING_COLOR = new Color(255, 156, 129, 255);
    private static final float LIGHTNING_WIDTH = 1.5f;
    private static final float LIGHTNING_LIFETIME = 0.2f;
    private static final float SPAWN_CHANCE = 0.85f;
    private final Lightning lightning = new Lightning(LIGHTNING_COLOR, LIGHTNING_WIDTH, LIGHTNING_LIFETIME,15);
    private final Random random = new Random();
    private float currentAlpha = 0.5f;

    public AlphaUtil alphaUtil;
    @Override
    public void init(CargoStackAPI stack) {
        super.init(stack);
        this.alphaUtil = new AlphaUtil(0.4f, 0.6f, 0.8f, 0.012f);
    }
    @Override
    public void render(float x, float y, float w, float h, float alphaMult, float glowMult, SpecialItemRendererAPI renderer) {
        float centerX = x + w * 0.5f;
        float centerY = y + h * 0.5f;

        if (random.nextFloat() < SPAWN_CHANCE) {
            float length = 30; // Example length, you can adjust this
            float angleMin = 295; // Minimum angle
            float angleMax = 310; // Maximum angle

            lightning.spawnLightningArc(centerX + 4, centerY - 8, length, angleMin+3, angleMax+3);
            lightning.spawnLightningArc(centerX + 4, centerY - 8, length, angleMin+3, angleMax+3);
//            lightning.spawnLightningArc(centerX , centerY - 5, length, angleMin, angleMax);
//            lightning.spawnLightningArc(centerX + 8, centerY - 2, length, angleMin-20, angleMax-20);
        }

        AoTDMisc.startStencil(x, y + 8, w - 20, h);
        SpriteAPI lightningSprite = Global.getSettings().getSprite("rendering", "lightning_bolt");
        lightning.render(1f, lightningSprite);
        AoTDMisc.endStencil();
        SpriteAPI staticSprite = Global.getSettings().getSprite("rendering", "tap_glow");
        staticSprite.setColor(LIGHTNING_COLOR);
        staticSprite.setAdditiveBlend();
        staticSprite.setAlphaMult(alphaUtil.getAlphaMult());
        staticSprite.renderAtCenter(centerX, centerY);
    }
}
