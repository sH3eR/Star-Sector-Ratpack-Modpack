package kaysaar.data.scripts.campaign.econ.items;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.impl.items.GenericSpecialItemPlugin;
import com.fs.starfarer.api.graphics.SpriteAPI;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.Random;

public class AnimatedHolomaker extends GenericSpecialItemPlugin {
    private SpriteAPI texture;
    private final Random random = new Random();
    private float timeSinceLastGlitch = 0f;  // Time since the last glitch
    private float glitchInterval = 2f;  // Interval between glitches in seconds
    private float[] segmentOffsets;  // Store the offsets for glitch effect

    @Override
    public void init(CargoStackAPI stack) {
        super.init(stack);
        texture = Global.getSettings().getSprite("rendering", "shimmer");
        segmentOffsets = new float[32];  // Assuming 4 segments for glitch effect
        updateSegmentOffsets();  // Initialize offsets
    }

    public void update(float amount) {
        timeSinceLastGlitch += amount;
        if (timeSinceLastGlitch >= glitchInterval) {
            timeSinceLastGlitch = 0f;  // Reset the timer
            updateSegmentOffsets();  // Update offsets for glitch effect
        }
    }

    private void updateSegmentOffsets() {
        for (int i = 0; i < segmentOffsets.length; i++) {
            segmentOffsets[i] = (i % 2 == 0) ? random.nextFloat() * 10f : -random.nextFloat() * 10f;
        }
    }

    @Override
    public void render(float x, float y, float w, float h, float alphaMult, float glowMult, SpecialItemRendererAPI renderer) {
        texture.bindTexture();

        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_BLEND);
        texture.setAdditiveBlend();
        float width,height,xcor,ycor;
        xcor=x+30;
        ycor=y+30;
        height = 43;
        width = 40;
        int segmentCount = segmentOffsets.length;  // Number of segments for the glitch effect
        float segmentHeight = height / segmentCount;

        for (int i = 0; i < segmentCount; i++) {
            float segmentOffsetX = segmentOffsets[i];

            GL11.glBegin(GL11.GL_QUADS);
            GL11.glColor4f(Color.WHITE.getRed() / 255f, Color.WHITE.getGreen() / 255f, Color.WHITE.getBlue() / 255f, alphaMult*0.25f);

            GL11.glTexCoord2f(0, (i * segmentHeight) / width);
            GL11.glVertex2f(xcor + segmentOffsetX, ycor + i * segmentHeight);
            GL11.glTexCoord2f(1, (i * segmentHeight) / width);
            GL11.glVertex2f(xcor + width + segmentOffsetX, ycor + i * segmentHeight);
            GL11.glTexCoord2f(1, ((i + 1) * segmentHeight) / width);
            GL11.glVertex2f(xcor + width + segmentOffsetX, ycor + (i + 1) * segmentHeight);
            GL11.glTexCoord2f(0, ((i + 1) * segmentHeight) / width);
            GL11.glVertex2f(xcor + segmentOffsetX, ycor + (i + 1) * segmentHeight);
            GL11.glEnd();
        }

        GL11.glPopMatrix();
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        update(0.064f);
    }
}
