package kaysaar.data.scripts.campaign.econ.items;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.impl.items.GenericSpecialItemPlugin;
import com.fs.starfarer.api.graphics.SpriteAPI;
import kaysaar.data.scripts.campaign.econ.items.models.AlphaUtil;
import kaysaar.data.scripts.campaign.econ.items.models.Particle;
import kaysaar.data.scripts.misc.AoTDMisc;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class AnimatedCatalyticCore extends GenericSpecialItemPlugin {
    private AlphaUtil alphaUtilBeat;
    private AlphaUtil alphaUtil;
    private final List<Particle> particles = new ArrayList<>();
    private final Random random = new Random();
    private boolean usedFirstTime = false;

    private final float particleSpeedMin = 2f;  // Minimum speed of particles
    private final float particleSpeedRange = 4f;  // Range for randomizing particle speed
    // Variables for easy configuration
    private final float particleFrequency = 0.2f;
    private Color Fumes = new Color(255,210,186);

    private void spawnInitialParticles(float centerX,float centerY) {
        // Adjust the starting positions and parameters as needed
        spawnParticleManual(centerX - 20, centerY-10);
    }

    private void spawnParticleManual(float x, float y){
        spawnParticle(x, y-5 , 10, 90, 60, Fumes);
    }
    private void spawnParticle(float x, float y, float w, float particleDirectionMin, float particleDirectionRange, Color color) {
        float angle = particleDirectionMin + random.nextFloat() * particleDirectionRange;  // Randomize the angle around the specified range
        float speed = particleSpeedMin + random.nextFloat() * particleSpeedRange;  // Randomize speed
        Vector2f velocity = new Vector2f((float) Math.cos(Math.toRadians(angle)) * speed, (float) Math.sin(Math.toRadians(angle)) * speed);
        float life = 14f + random.nextFloat();  // Randomize life duration
        float spawnX = x + random.nextFloat() * w;  // Randomize X spawn position over the width of the engine
        SpriteAPI sprite = Global.getSettings().getSprite("rendering","particle_"+random.nextInt(12));
        particles.add(new Particle(new Vector2f(spawnX, y), velocity, life, color,sprite));
    }
    @Override
    public void init(CargoStackAPI stack) {
        super.init(stack);
        this.alphaUtil = new AlphaUtil(0.6f, 0.6f, 0.8f, 0.001f);
        this.alphaUtilBeat = new AlphaUtil(0.5f, 0.5f, 0.95f, 0.01f, true, 4.0f); // Enable heartbeat mode with a pause duration of 1 second


    }

    @Override
    public void render(float x, float y, float w, float h, float alphaMult, float glowMult, SpecialItemRendererAPI renderer) {
        float centerX = x + w * 0.5f;
        float centerY = y + h * 0.5f;

        // Static sprite rendering
        SpriteAPI staticSprite = Global.getSettings().getSprite("rendering", "catalytic_2");
        staticSprite.setColor(new Color(243, 137, 112, 255));
        staticSprite.setAdditiveBlend();
        staticSprite.setAlphaMult(alphaUtil.getAlphaMult());
        staticSprite.renderAtCenter(centerX, centerY);
        SpriteAPI staticSprite2 = Global.getSettings().getSprite("rendering", "catalytic_1");
        staticSprite2.setColor(new Color(56, 255, 255, 255));
        staticSprite2.setAdditiveBlend();
        staticSprite2.setAlphaMult(alphaUtilBeat.getAlphaMult());
        staticSprite2.renderAtCenter(centerX, centerY);
        staticSprite2.setColor(new Color(56, 255, 255, 255));
        staticSprite2.setAdditiveBlend();
        staticSprite2.setAlphaMult(alphaUtilBeat.getAlphaMult());
        staticSprite2.renderAtCenter(centerX, centerY);

        AoTDMisc.startStencil(x, y +15, w, h);
        if(!usedFirstTime){
            for (int i = 0; i < 60; i++) {  // Adjust the number based on how many particles you want initially
                spawnInitialParticles(centerX , centerY );
                for (Particle particle : particles) {
                    particle.update(0.2f);  // Update with a fixed timestep
                }
            }

        }

        if(usedFirstTime){
            for (Particle particle : particles) {
                particle.update(0.016f);  // Update with a fixed timestep
            }
        }
        if(!usedFirstTime){
            usedFirstTime = true;
            return;
        }
        // Particle spawning
        if (random.nextFloat() < particleFrequency) {  // Adjust particle spawning frequency
            spawnParticleManual(centerX - 20, centerY-10);
        }

        // Particle updating and rendering
        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_BLEND);
        int blendFunc1 = GL11.GL_SRC_ALPHA;
        int blendFunc2 = GL11.GL_ONE_MINUS_SRC_ALPHA;
        GL11.glBlendFunc(blendFunc1, blendFunc2);



        Iterator<Particle> iterator = particles.iterator();
        while (iterator.hasNext()) {
            Particle particle = iterator.next();
            if (!particle.isAlive()) {
                iterator.remove();
                continue;
            }
            particle.particleSprite.bindTexture();
            float particleAlpha =  particle.getAlpha(25f);
            GL11.glColor4f(particle.color.getRed() / 255f, particle.color.getGreen() / 255f, particle.color.getBlue() / 255f, particleAlpha);

            float particleX = particle.position.x;
            float particleY = particle.position.y;
            float particleSize = 10f;

            GL11.glBegin(GL11.GL_QUADS);
            GL11.glTexCoord2f(0, 0);
            GL11.glVertex2f(particleX - particleSize / 2, particleY - particleSize / 2);
            GL11.glTexCoord2f(1, 0);
            GL11.glVertex2f(particleX + particleSize / 2, particleY - particleSize / 2);
            GL11.glTexCoord2f(1, 1);
            GL11.glVertex2f(particleX + particleSize / 2, particleY + particleSize / 2);
            GL11.glTexCoord2f(0, 1);
            GL11.glVertex2f(particleX - particleSize / 2, particleY + particleSize / 2);
            GL11.glEnd();
        }
        AoTDMisc.endStencil();
        GL11.glPopMatrix();
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);

    }
}


