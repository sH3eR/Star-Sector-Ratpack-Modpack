package kaysaar.data.scripts.campaign.econ.items;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.impl.items.GenericSpecialItemPlugin;
import com.fs.starfarer.api.graphics.SpriteAPI;
import kaysaar.data.scripts.campaign.econ.items.models.Lightning;
import kaysaar.data.scripts.misc.AoTDMisc;


import java.awt.Color;
import java.util.Random;

public class AnimatedCorruptedNanoforgePlugin extends GenericSpecialItemPlugin {
    private static final Color LIGHTNING_COLOR = new Color(252, 42, 42, 255);
    private static final Color LIGHTNING_COLOR2 = new Color(241, 66, 66, 255);
    private static final float LIGHTNING_WIDTH = 2f;
    private static final float LIGHTNING_LIFETIME = 0.6f;
    private static final float SPAWN_CHANCE = 0.45f;
    private final Random random = new Random();

    private float currentAlpha = 0.4f;
    private boolean reverse = false;
    private final float speed = 0.002f;

    private final Lightning lightning = new Lightning(LIGHTNING_COLOR, LIGHTNING_WIDTH, LIGHTNING_LIFETIME,35);

    private float getAlphaMult() {
        if (!reverse) {
            currentAlpha += speed;
        }
        if (currentAlpha >= 0.5f) {
            reverse = true;
        }
        if (reverse) {
            currentAlpha -= speed;
        }
        if (currentAlpha <= 0.3f) {
            reverse = false;
        }
        return currentAlpha;
    }

    @Override
    public void render(float x, float y, float w, float h, float alphaMult, float glowMult, SpecialItemRendererAPI renderer) {
        float centerX = x + w * 0.5f;
        float centerY = y + h * 0.5f;

        if (random.nextFloat() < SPAWN_CHANCE) {
            float length = 10; // Example length, you can adjust this
            float angleMin = 1; // Minimum angle
            float angleMax = 90; // Maximum angle
            lightning.spawnLightningArc(centerX + 25, centerY, length, angleMin, angleMax);
        }

        AoTDMisc.startStencil(x, y + 5, w - 18, h - 10);
        SpriteAPI lightningSprite = Global.getSettings().getSprite("rendering", "lightning_bolt");
        lightning.render(0f, lightningSprite);
        AoTDMisc.endStencil();

        SpriteAPI staticSprite = Global.getSettings().getSprite("rendering", "nanoforge_glow_2");
        staticSprite.setColor(LIGHTNING_COLOR2);
        staticSprite.setAdditiveBlend();
        staticSprite.setAlphaMult(getAlphaMult());
        staticSprite.renderAtCenter(centerX, centerY);
    }
}
