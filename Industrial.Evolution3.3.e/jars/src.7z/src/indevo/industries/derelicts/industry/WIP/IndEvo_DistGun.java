package industrialevolution.industries.derelicts.industry;

//planet cracker gun
//Manufactures its' own receiver artefact, once a year (red. with cores), stockpiles 3
//can convert a nanoforge into a receiver artifact immediately

//can auto-zap pirate and path stations.

//Deploy receiver artefact in target system
//select target system from cannon menu
//murder planet/station

//can do animation: 3 beams, one after another into central array, shooting into some station orbiting the planet
//Animation in other system: artefact starts spinning and glowing, then do 0.5s massive beam with afterglow, and spawn explosion on planet.
//deciv the planet, replace graphic with resized "broken planet" texture
//stations just despawn
//could make it actually spawn a wormhole

public class IndEvo_DistGun {
}
