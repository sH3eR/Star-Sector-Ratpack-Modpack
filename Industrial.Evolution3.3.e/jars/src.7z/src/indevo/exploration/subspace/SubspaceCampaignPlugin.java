package indevo.exploration.subspace;

public class SubspaceCampaignPlugin {
}
